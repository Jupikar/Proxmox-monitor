'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';
import { Loader2, TrendingUp, Clock, RefreshCw } from 'lucide-react';

interface MetricsChartProps {
  lxcId?: string;
  lxcName?: string;
  metric: 'cpu' | 'memory' | 'disk' | 'network';
  title: string;
  color?: string;
}

type Period = '1h' | '6h' | '24h' | '7d' | '30d';

const PERIODS: { value: Period; label: string }[] = [
  { value: '1h', label: '1h' },
  { value: '6h', label: '6h' },
  { value: '24h', label: '24h' },
  { value: '7d', label: '7j' },
  { value: '30d', label: '30j' },
];

const COLORS = {
  cpu: '#3b82f6',
  memory: '#10b981',
  disk: '#f59e0b',
  netIn: '#8b5cf6',
  netOut: '#ec4899',
};

export default function MetricsChart({ lxcId, lxcName, metric, title, color }: MetricsChartProps) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>('24h');
  const [error, setError] = useState<string | null>(null);
  
  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const params = new URLSearchParams({ period });
      if (lxcId) params.append('lxcId', lxcId);
      
      const response = await fetch(`/api/metrics/history?${params}`);
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result?.error || 'Erreur de chargement');
      }
      
      // Transformer les données pour le graphique
      const chartData = result?.metrics?.map((m: any) => ({
        timestamp: new Date(m.timestamp).getTime(),
        time: formatTime(new Date(m.timestamp), period),
        cpu: m.cpu?.toFixed(1),
        memory: m.memory?.toFixed(1),
        disk: m.disk?.toFixed(1),
        netIn: formatBytes(m.netIn),
        netOut: formatBytes(m.netOut),
        netInRaw: m.netIn,
        netOutRaw: m.netOut,
        lxcName: m.lxc?.name || 'LXC',
      })) || [];
      
      setData(chartData);
      
    } catch (err: any) {
      setError(err?.message || 'Erreur de chargement');
    } finally {
      setLoading(false);
    }
  }, [lxcId, period]);
  
  useEffect(() => {
    fetchData();
  }, [fetchData]);
  
  const formatTime = (date: Date, p: Period) => {
    if (p === '1h' || p === '6h') {
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } else if (p === '24h') {
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
    }
  };
  
  const formatBytes = (bytes: number) => {
    if (!bytes) return 0;
    const mb = bytes / (1024 * 1024);
    return mb.toFixed(2);
  };
  
  const getMetricValue = () => {
    switch (metric) {
      case 'cpu':
        return { key: 'cpu', unit: '%', color: color || COLORS.cpu };
      case 'memory':
        return { key: 'memory', unit: '%', color: color || COLORS.memory };
      case 'disk':
        return { key: 'disk', unit: '%', color: color || COLORS.disk };
      case 'network':
        return { key: 'netInRaw', unit: 'MB', color: color || COLORS.netIn };
      default:
        return { key: 'cpu', unit: '%', color: COLORS.cpu };
    }
  };
  
  const metricConfig = getMetricValue();
  
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border rounded-lg shadow-lg p-3">
          <p className="text-sm font-medium mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {entry.value}{metric !== 'network' ? '%' : ' MB'}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg bg-card p-4 shadow-md"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">{title}</h3>
          {lxcName && (
            <span className="text-sm text-muted-foreground">({lxcName})</span>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg bg-muted p-1">
            {PERIODS.map((p) => (
              <button
                key={p.value}
                onClick={() => setPeriod(p.value)}
                className={`px-2 py-1 text-xs rounded transition-colors ${
                  period === p.value
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted-foreground/20'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          
          <button
            onClick={fetchData}
            disabled={loading}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Rafraîchir"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="h-64 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : error ? (
        <div className="h-64 flex items-center justify-center text-red-500">
          {error}
        </div>
      ) : data.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center text-muted-foreground">
          <Clock className="h-12 w-12 mb-2 opacity-50" />
          <p>Aucune donnée pour cette période</p>
          <p className="text-sm">Les métriques sont collectées automatiquement</p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={250}>
          {metric === 'network' ? (
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
              <XAxis
                dataKey="time"
                stroke="#9ca3af"
                fontSize={12}
                tickLine={false}
              />
              <YAxis
                stroke="#9ca3af"
                fontSize={12}
                tickLine={false}
                tickFormatter={(v) => `${(v / 1024 / 1024).toFixed(0)}`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Area
                type="monotone"
                dataKey="netInRaw"
                name="Entrée"
                stroke={COLORS.netIn}
                fill={COLORS.netIn}
                fillOpacity={0.3}
              />
              <Area
                type="monotone"
                dataKey="netOutRaw"
                name="Sortie"
                stroke={COLORS.netOut}
                fill={COLORS.netOut}
                fillOpacity={0.3}
              />
            </AreaChart>
          ) : (
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
              <XAxis
                dataKey="time"
                stroke="#9ca3af"
                fontSize={12}
                tickLine={false}
              />
              <YAxis
                stroke="#9ca3af"
                fontSize={12}
                tickLine={false}
                domain={[0, 100]}
                tickFormatter={(v) => `${v}%`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey={metricConfig.key}
                name={title}
                stroke={metricConfig.color}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          )}
        </ResponsiveContainer>
      )}
    </motion.div>
  );
}
