'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  AlertTriangle,
  RefreshCw,
  CheckCircle,
  Package,
  Clock,
  ChevronDown,
  ChevronUp,
  Loader2,
  Download,
  X,
  Settings,
  Calendar,
  Play,
  Pause,
} from 'lucide-react';

interface UpdateInfo {
  id: string;
  lxcId: string;
  containerName: string;
  imageName: string;
  currentTag: string;
  hasUpdate: boolean;
  lastChecked: string;
}

interface UpdateSummary {
  totalUpdates: number;
  byLxc: { [key: string]: UpdateInfo[] };
  lastChecked: string | null;
}

interface LXCConfig {
  id: string;
  name: string;
}

interface ScheduleConfig {
  lxcId: string;
  lxcName: string;
  schedule: string | null;
  enabled: boolean;
}

const SCHEDULE_PRESETS = [
  { label: 'Toutes les heures', value: '0 * * * *' },
  { label: 'Toutes les 6 heures', value: '0 */6 * * *' },
  { label: 'Tous les jours à 6h', value: '0 6 * * *' },
  { label: 'Tous les jours à minuit', value: '0 0 * * *' },
  { label: 'Tous les lundis à 6h', value: '0 6 * * 1' },
  { label: 'Personnalisé', value: 'custom' },
];

export default function DockerUpdates() {
  const [summary, setSummary] = useState<UpdateSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Schedule modal state
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [lxcs, setLxcs] = useState<LXCConfig[]>([]);
  const [selectedLxcId, setSelectedLxcId] = useState<string>('');
  const [scheduleConfigs, setScheduleConfigs] = useState<Map<string, ScheduleConfig>>(new Map());
  const [selectedPreset, setSelectedPreset] = useState<string>('0 6 * * *');
  const [customSchedule, setCustomSchedule] = useState<string>('');
  const [appUrl, setAppUrl] = useState<string>('');
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [scheduleError, setScheduleError] = useState<string | null>(null);
  const [scheduleSuccess, setScheduleSuccess] = useState<string | null>(null);
  const [loadingSchedule, setLoadingSchedule] = useState(false);
  
  const fetchSummary = useCallback(async () => {
    try {
      const response = await fetch('/api/docker/updates/check-all');
      const data = await response.json();
      
      if (data?.success) {
        setSummary(data);
        setError(null);
      } else {
        setError(data?.error || 'Erreur de chargement');
      }
    } catch (err: any) {
      setError(err?.message || 'Erreur de connexion');
    } finally {
      setLoading(false);
    }
  }, []);
  
  const fetchLxcs = useCallback(async () => {
    try {
      const response = await fetch('/api/lxc/config');
      const data = await response.json();
      if (data?.lxcs) {
        setLxcs(data.lxcs);
        if (data.lxcs.length > 0 && !selectedLxcId) {
          setSelectedLxcId(data.lxcs[0].id);
        }
      }
    } catch (err) {
      console.error('Erreur chargement LXC:', err);
    }
  }, [selectedLxcId]);
  
  const fetchScheduleConfig = useCallback(async (lxcId: string) => {
    if (!lxcId) return;
    
    setLoadingSchedule(true);
    try {
      const response = await fetch(`/api/docker/updates/schedule?lxcId=${lxcId}`);
      const data = await response.json();
      
      if (data?.success) {
        setScheduleConfigs(prev => new Map(prev).set(lxcId, data));
        
        // Update preset selection based on current schedule
        if (data.schedule) {
          const preset = SCHEDULE_PRESETS.find(p => p.value === data.schedule);
          if (preset) {
            setSelectedPreset(data.schedule);
          } else {
            setSelectedPreset('custom');
            setCustomSchedule(data.schedule);
          }
        }
      }
    } catch (err) {
      console.error('Erreur chargement config:', err);
    } finally {
      setLoadingSchedule(false);
    }
  }, []);
  
  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);
  
  useEffect(() => {
    if (showScheduleModal) {
      fetchLxcs();
      // Detect current URL for the cron command
      setAppUrl(window.location.origin);
    }
  }, [showScheduleModal, fetchLxcs]);
  
  useEffect(() => {
    if (selectedLxcId && showScheduleModal) {
      fetchScheduleConfig(selectedLxcId);
    }
  }, [selectedLxcId, showScheduleModal, fetchScheduleConfig]);
  
  const checkAllUpdates = async () => {
    setChecking(true);
    setError(null);
    
    try {
      const response = await fetch('/api/docker/updates/check-all', {
        method: 'POST',
      });
      
      const data = await response.json();
      
      if (data?.success) {
        await fetchSummary();
      } else {
        setError(data?.error || 'Erreur lors de la vérification');
      }
    } catch (err: any) {
      setError(err?.message || 'Erreur de connexion');
    } finally {
      setChecking(false);
    }
  };
  
  const saveSchedule = async (enabled: boolean) => {
    setSavingSchedule(true);
    setScheduleError(null);
    setScheduleSuccess(null);
    
    const schedule = selectedPreset === 'custom' ? customSchedule : selectedPreset;
    
    if (enabled && !schedule) {
      setScheduleError('Veuillez sélectionner une planification');
      setSavingSchedule(false);
      return;
    }
    
    try {
      const response = await fetch('/api/docker/updates/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          lxcId: selectedLxcId,
          schedule,
          enabled,
          appUrl,
        }),
      });
      
      const data = await response.json();
      
      if (data?.success) {
        setScheduleSuccess(data.message);
        // Refresh config
        await fetchScheduleConfig(selectedLxcId);
      } else {
        setScheduleError(data?.error || 'Erreur de configuration');
      }
    } catch (err: any) {
      setScheduleError(err?.message || 'Erreur de connexion');
    } finally {
      setSavingSchedule(false);
    }
  };
  
  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return 'Jamais';
    const date = new Date(dateStr);
    return date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  const currentConfig = scheduleConfigs.get(selectedLxcId);
  
  if (loading) {
    return (
      <div className="rounded-lg bg-card p-4 shadow-md">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Chargement des mises à jour...</span>
        </div>
      </div>
    );
  }
  
  const hasUpdates = (summary?.totalUpdates || 0) > 0;
  
  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={`rounded-lg p-4 shadow-md border ${
          hasUpdates
            ? 'bg-orange-500/10 border-orange-500/30'
            : 'bg-green-500/10 border-green-500/30'
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {hasUpdates ? (
              <div className="p-2 rounded-full bg-orange-500/20">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
              </div>
            ) : (
              <div className="p-2 rounded-full bg-green-500/20">
                <CheckCircle className="h-5 w-5 text-green-500" />
              </div>
            )}
            
            <div>
              <h3 className="font-semibold">
                {hasUpdates
                  ? `${summary?.totalUpdates} mise(s) à jour disponible(s)`
                  : 'Tous les conteneurs sont à jour'}
              </h3>
              <p className="text-sm text-muted-foreground flex items-center gap-1">
                <Clock className="h-3 w-3" />
                Dernière vérification: {formatDate(summary?.lastChecked || null)}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowScheduleModal(true)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-muted text-muted-foreground text-sm hover:bg-muted/80 transition-colors"
              title="Configurer la vérification automatique"
            >
              <Calendar className="h-4 w-4" />
              <span className="hidden sm:inline">Planifier</span>
            </button>
            
            <button
              onClick={checkAllUpdates}
              disabled={checking}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm hover:bg-primary/90 transition-colors disabled:opacity-50"
            >
              {checking ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="h-4 w-4" />
              )}
              Vérifier
            </button>
            
            {hasUpdates && (
              <button
                onClick={() => setExpanded(!expanded)}
                className="p-1.5 rounded-lg hover:bg-muted transition-colors"
              >
                {expanded ? (
                  <ChevronUp className="h-5 w-5" />
                ) : (
                  <ChevronDown className="h-5 w-5" />
                )}
              </button>
            )}
          </div>
        </div>
        
        {error && (
          <div className="mt-3 p-2 rounded bg-red-500/20 text-red-500 text-sm flex items-center gap-2">
            <X className="h-4 w-4" />
            {error}
          </div>
        )}
        
        <AnimatePresence>
          {expanded && hasUpdates && summary?.byLxc && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              <div className="mt-4 space-y-3">
                {Object.entries(summary.byLxc).map(([lxcName, updates]) => (
                  <div key={lxcName} className="rounded-lg bg-card/50 p-3">
                    <h4 className="font-medium mb-2 flex items-center gap-2">
                      <Package className="h-4 w-4" />
                      {lxcName}
                      <span className="text-xs bg-orange-500 text-white px-2 py-0.5 rounded-full">
                        {updates.length}
                      </span>
                    </h4>
                    <div className="space-y-1">
                      {updates.map((update) => (
                        <div
                          key={update.id}
                          className="flex items-center justify-between text-sm py-1 px-2 rounded hover:bg-muted/50"
                        >
                          <div className="flex items-center gap-2">
                            <Download className="h-3 w-3 text-orange-500" />
                            <span className="font-mono">{update.containerName}</span>
                          </div>
                          <span className="text-muted-foreground text-xs">
                            {update.imageName}:{update.currentTag}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
      
      {/* Schedule Modal */}
      <AnimatePresence>
        {showScheduleModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => setShowScheduleModal(false)}
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-card rounded-xl shadow-xl max-w-lg w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <Settings className="h-5 w-5" />
                    Vérification automatique
                  </h2>
                  <button
                    onClick={() => setShowScheduleModal(false)}
                    className="p-1 rounded-lg hover:bg-muted transition-colors"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                
                <div className="space-y-4">
                  {/* LXC Selection */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      LXC pour exécuter le cron
                    </label>
                    <select
                      value={selectedLxcId}
                      onChange={(e) => setSelectedLxcId(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-muted border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      {lxcs.map((lxc) => (
                        <option key={lxc.id} value={lxc.id}>
                          {lxc.name}
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-muted-foreground mt-1">
                      Le cron sera configuré sur ce LXC pour vérifier les mises à jour
                    </p>
                  </div>
                  
                  {/* Current Status */}
                  {loadingSchedule ? (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Chargement de la configuration...
                    </div>
                  ) : currentConfig && (
                    <div className={`p-3 rounded-lg ${
                      currentConfig.enabled
                        ? 'bg-green-500/10 border border-green-500/30'
                        : 'bg-muted'
                    }`}>
                      <div className="flex items-center gap-2">
                        {currentConfig.enabled ? (
                          <Play className="h-4 w-4 text-green-500" />
                        ) : (
                          <Pause className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="font-medium">
                          {currentConfig.enabled ? 'Actif' : 'Inactif'}
                        </span>
                      </div>
                      {currentConfig.enabled && currentConfig.schedule && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Planification: <code className="bg-muted px-1 rounded">{currentConfig.schedule}</code>
                        </p>
                      )}
                    </div>
                  )}
                  
                  {/* Schedule Preset */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Fréquence de vérification
                    </label>
                    <select
                      value={selectedPreset}
                      onChange={(e) => {
                        setSelectedPreset(e.target.value);
                        if (e.target.value !== 'custom') {
                          setCustomSchedule('');
                        }
                      }}
                      className="w-full px-3 py-2 rounded-lg bg-muted border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      {SCHEDULE_PRESETS.map((preset) => (
                        <option key={preset.value} value={preset.value}>
                          {preset.label}
                        </option>
                      ))}
                    </select>
                  </div>
                  
                  {/* Custom Schedule */}
                  {selectedPreset === 'custom' && (
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Expression cron personnalisée
                      </label>
                      <input
                        type="text"
                        value={customSchedule}
                        onChange={(e) => setCustomSchedule(e.target.value)}
                        placeholder="0 6 * * *"
                        className="w-full px-3 py-2 rounded-lg bg-muted border border-border focus:outline-none focus:ring-2 focus:ring-primary font-mono"
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Format: minute heure jour mois jour_semaine
                      </p>
                    </div>
                  )}
                  
                  {/* App URL */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      URL de l'application
                    </label>
                    <input
                      type="text"
                      value={appUrl}
                      onChange={(e) => setAppUrl(e.target.value)}
                      placeholder="http://localhost:3000"
                      className="w-full px-3 py-2 rounded-lg bg-muted border border-border focus:outline-none focus:ring-2 focus:ring-primary font-mono text-sm"
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      L'URL utilisée par le cron pour appeler l'API
                    </p>
                  </div>
                  
                  {/* Error/Success Messages */}
                  {scheduleError && (
                    <div className="p-3 rounded-lg bg-red-500/20 text-red-500 text-sm">
                      {scheduleError}
                    </div>
                  )}
                  
                  {scheduleSuccess && (
                    <div className="p-3 rounded-lg bg-green-500/20 text-green-500 text-sm">
                      {scheduleSuccess}
                    </div>
                  )}
                  
                  {/* Actions */}
                  <div className="flex gap-3 pt-4">
                    {currentConfig?.enabled ? (
                      <button
                        onClick={() => saveSchedule(false)}
                        disabled={savingSchedule}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-red-500/20 text-red-500 hover:bg-red-500/30 transition-colors disabled:opacity-50"
                      >
                        {savingSchedule ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Pause className="h-4 w-4" />
                        )}
                        Désactiver
                      </button>
                    ) : null}
                    
                    <button
                      onClick={() => saveSchedule(true)}
                      disabled={savingSchedule}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors disabled:opacity-50"
                    >
                      {savingSchedule ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Play className="h-4 w-4" />
                      )}
                      {currentConfig?.enabled ? 'Mettre à jour' : 'Activer'}
                    </button>
                  </div>
                  
                  {/* Info */}
                  <div className="text-xs text-muted-foreground bg-muted/50 p-3 rounded-lg mt-4">
                    <p className="font-medium mb-1">Commande cron générée :</p>
                    <code className="block bg-muted p-2 rounded text-xs overflow-x-auto">
                      {selectedPreset === 'custom' ? customSchedule : selectedPreset} curl -s -X POST {appUrl}/api/docker/updates/check-all
                    </code>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
