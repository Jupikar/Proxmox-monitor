'use client';

import { useState, useRef, useEffect, KeyboardEvent } from 'react';
import { Loader2, Terminal as TerminalIcon } from 'lucide-react';

interface SSHTerminalProps {
  lxcId: string;
  lxcName: string;
}

interface HistoryEntry {
  command: string;
  output: string;
  timestamp: Date;
}

export default function SSHTerminal({ lxcId, lxcName }: SSHTerminalProps) {
  const [command, setCommand] = useState('');
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [isExecuting, setIsExecuting] = useState(false);
  const [currentDir, setCurrentDir] = useState('~');
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [history]);
  
  useEffect(() => {
    // Récupérer le répertoire courant au démarrage
    executeCommand('pwd', true);
  }, [lxcId]);
  
  const executeCommand = async (cmd: string, silent: boolean = false) => {
    if (!cmd.trim()) return;
    
    setIsExecuting(true);
    
    try {
      const response = await fetch('/api/ssh/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lxcId, command: cmd }),
      });
      
      const data = await response.json();
      
      if (silent) {
        if (data?.output) {
          setCurrentDir(data.output.trim());
        }
        return;
      }
      
      const entry: HistoryEntry = {
        command: cmd,
        output: data?.output || data?.error || '',
        timestamp: new Date(),
      };
      
      setHistory(prev => [...prev, entry]);
      
      // Mettre à jour le répertoire courant si c'est cd
      if (cmd.startsWith('cd ')) {
        const pwdResponse = await fetch('/api/ssh/exec', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ lxcId, command: 'pwd' }),
        });
        const pwdData = await pwdResponse.json();
        if (pwdData?.output) {
          setCurrentDir(pwdData.output.trim());
        }
      }
      
    } catch (error) {
      if (!silent) {
        setHistory(prev => [...prev, {
          command: cmd,
          output: 'Erreur de connexion',
          timestamp: new Date(),
        }]);
      }
    } finally {
      setIsExecuting(false);
    }
  };
  
  const handleSubmit = async () => {
    if (!command.trim() || isExecuting) return;
    
    const cmd = command.trim();
    
    // Ajouter à l'historique des commandes
    setCommandHistory(prev => [...prev.filter(c => c !== cmd), cmd]);
    setHistoryIndex(-1);
    setCommand('');
    
    // Commande spéciale clear
    if (cmd === 'clear') {
      setHistory([]);
      return;
    }
    
    await executeCommand(cmd);
  };
  
  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSubmit();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const newIndex = historyIndex < commandHistory.length - 1 ? historyIndex + 1 : historyIndex;
        setHistoryIndex(newIndex);
        setCommand(commandHistory[commandHistory.length - 1 - newIndex] || '');
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCommand(commandHistory[commandHistory.length - 1 - newIndex] || '');
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCommand('');
      }
    }
  };
  
  const focusInput = () => {
    inputRef.current?.focus();
  };
  
  return (
    <div className="h-full flex flex-col bg-[#1e1e1e] rounded-lg overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2 bg-[#2d2d2d] border-b border-[#3d3d3d]">
        <TerminalIcon className="h-4 w-4 text-green-500" />
        <span className="text-sm text-gray-300">
          {lxcName} - Terminal
        </span>
      </div>
      
      <div
        ref={terminalRef}
        className="flex-1 overflow-y-auto p-4 font-mono text-sm cursor-text"
        onClick={focusInput}
      >
        {/* Message de bienvenue */}
        <div className="text-green-500 mb-2">
          Connecté à {lxcName}
        </div>
        <div className="text-gray-500 mb-4 text-xs">
          Tapez vos commandes ci-dessous. Utilisez &apos;clear&apos; pour effacer le terminal.
        </div>
        
        {/* Historique */}
        {history.map((entry, index) => (
          <div key={index} className="mb-2">
            <div className="flex items-center gap-2">
              <span className="text-green-500">$</span>
              <span className="text-cyan-400">{currentDir}</span>
              <span className="text-white">{entry.command}</span>
            </div>
            {entry.output && (
              <pre className="text-gray-300 whitespace-pre-wrap mt-1 ml-4">
                {entry.output}
              </pre>
            )}
          </div>
        ))}
        
        {/* Ligne de commande active */}
        <div className="flex items-center gap-2">
          <span className="text-green-500">$</span>
          <span className="text-cyan-400">{currentDir}</span>
          <div className="flex-1 flex items-center">
            <input
              ref={inputRef}
              type="text"
              value={command}
              onChange={(e) => setCommand(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={isExecuting}
              className="flex-1 bg-transparent text-white outline-none border-none"
              autoFocus
              spellCheck={false}
            />
            {isExecuting && (
              <Loader2 className="h-4 w-4 animate-spin text-gray-500" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
