'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { Loader2, BarChart3, RefreshCw, Play } from 'lucide-react';

interface LXCOption {
  id: string;
  name: string;
  proxmoxId: number;
}

type Period = '1h' | '6h' | '24h' | '7d' | '30d';

const PERIODS: { value: Period; label: string }[] = [
  { value: '1h', label: '1h' },
  { value: '6h', label: '6h' },
  { value: '24h', label: '24h' },
  { value: '7d', label: '7j' },
  { value: '30d', label: '30j' },
];

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];

export default function MetricsOverview() {
  const [lxcs, setLxcs] = useState<LXCOption[]>([]);
  const [selectedLxc, setSelectedLxc] = useState<string>('all');
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<Period>('24h');
  const [collecting, setCollecting] = useState(false);
  
  useEffect(() => {
    fetchLxcs();
  }, []);
  
  const fetchLxcs = async () => {
    try {
      const response = await fetch('/api/lxc/config');
      const result = await response.json();
      setLxcs(result?.lxcs || []);
    } catch (error) {
      console.error('Erreur chargement LXCs:', error);
    }
  };
  
  const fetchData = useCallback(async () => {
    setLoading(true);
    
    try {
      const params = new URLSearchParams({ period });
      if (selectedLxc !== 'all') {
        params.append('lxcId', selectedLxc);
      }
      
      const response = await fetch(`/api/metrics/history?${params}`);
      const result = await response.json();
      
      if (result?.metrics) {
        // Grouper par timestamp pour avoir toutes les métriques ensemble
        const grouped: { [key: string]: any } = {};
        
        result.metrics.forEach((m: any) => {
          const timeKey = new Date(m.timestamp).getTime();
          const lxcName = m.lxc?.name || 'LXC';
          
          if (!grouped[timeKey]) {
            grouped[timeKey] = {
              timestamp: timeKey,
              time: formatTime(new Date(m.timestamp)),
            };
          }
          
          grouped[timeKey][`${lxcName}_cpu`] = parseFloat(m.cpu?.toFixed(1));
          grouped[timeKey][`${lxcName}_memory`] = parseFloat(m.memory?.toFixed(1));
          grouped[timeKey][`${lxcName}_disk`] = parseFloat(m.disk?.toFixed(1));
        });
        
        const chartData = Object.values(grouped).sort((a: any, b: any) => a.timestamp - b.timestamp);
        setData(chartData);
      }
      
    } catch (error) {
      console.error('Erreur chargement données:', error);
    } finally {
      setLoading(false);
    }
  }, [period, selectedLxc]);
  
  useEffect(() => {
    fetchData();
  }, [fetchData]);
  
  const formatTime = (date: Date) => {
    if (period === '1h' || period === '6h' || period === '24h') {
      return date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
    } else {
      return date.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
    }
  };
  
  const collectMetrics = async () => {
    setCollecting(true);
    
    try {
      const response = await fetch('/api/metrics/history', { method: 'POST' });
      const result = await response.json();
      
      if (result?.success) {
        // Rafraîchir les données après collecte
        setTimeout(fetchData, 500);
      }
    } catch (error) {
      console.error('Erreur collecte:', error);
    } finally {
      setCollecting(false);
    }
  };
  
  // Déterminer les clés de données pour les lignes
  const getDataKeys = () => {
    if (data.length === 0) return [];
    
    const keys = Object.keys(data[0]).filter(
      key => key.endsWith('_cpu') || key.endsWith('_memory') || key.endsWith('_disk')
    );
    
    return keys;
  };
  
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border rounded-lg shadow-lg p-3 max-w-xs">
          <p className="text-sm font-medium mb-2">{label}</p>
          {payload.map((entry: any, index: number) => {
            const [lxcName, metricType] = entry.dataKey.split('_');
            const metricLabel = metricType === 'cpu' ? 'CPU' : metricType === 'memory' ? 'RAM' : 'Disque';
            return (
              <p key={index} className="text-xs" style={{ color: entry.color }}>
                {lxcName} - {metricLabel}: {entry.value}%
              </p>
            );
          })}
        </div>
      );
    }
    return null;
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg bg-card p-6 shadow-md"
    >
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-2">
          <BarChart3 className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Historique des métriques</h2>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={selectedLxc}
            onChange={(e) => setSelectedLxc(e.target.value)}
            className="px-3 py-1.5 rounded-lg border bg-background text-sm"
          >
            <option value="all">Tous les LXC</option>
            {lxcs.map((lxc) => (
              <option key={lxc.id} value={lxc.id}>
                {lxc.name}
              </option>
            ))}
          </select>
          
          <div className="flex rounded-lg bg-muted p-1">
            {PERIODS.map((p) => (
              <button
                key={p.value}
                onClick={() => setPeriod(p.value)}
                className={`px-2 py-1 text-xs rounded transition-colors ${
                  period === p.value
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted-foreground/20'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          
          <button
            onClick={collectMetrics}
            disabled={collecting}
            className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-green-600 text-white text-sm hover:bg-green-700 transition-colors disabled:opacity-50"
            title="Collecter les métriques maintenant"
          >
            {collecting ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Play className="h-4 w-4" />
            )}
            Collecter
          </button>
          
          <button
            onClick={fetchData}
            disabled={loading}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Rafraîchir"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      
      {loading ? (
        <div className="h-80 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      ) : data.length === 0 ? (
        <div className="h-80 flex flex-col items-center justify-center text-muted-foreground">
          <BarChart3 className="h-16 w-16 mb-4 opacity-50" />
          <p className="text-lg font-medium mb-2">Aucune donnée disponible</p>
          <p className="text-sm text-center max-w-md">
            Cliquez sur &quot;Collecter&quot; pour enregistrer les métriques actuelles,
            ou attendez la collecte automatique.
          </p>
        </div>
      ) : (
        <ResponsiveContainer width="100%" height={350}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.3} />
            <XAxis
              dataKey="time"
              stroke="#9ca3af"
              fontSize={12}
              tickLine={false}
            />
            <YAxis
              stroke="#9ca3af"
              fontSize={12}
              tickLine={false}
              domain={[0, 100]}
              tickFormatter={(v) => `${v}%`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend
              formatter={(value) => {
                const [lxcName, metricType] = value.split('_');
                const metricLabel = metricType === 'cpu' ? 'CPU' : metricType === 'memory' ? 'RAM' : 'Disque';
                return `${lxcName} - ${metricLabel}`;
              }}
            />
            {getDataKeys().map((key, index) => (
              <Line
                key={key}
                type="monotone"
                dataKey={key}
                stroke={COLORS[index % COLORS.length]}
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      )}
      
      <div className="mt-4 text-xs text-muted-foreground text-center">
        Les métriques sont conservées pendant 30 jours
      </div>
    </motion.div>
  );
}
