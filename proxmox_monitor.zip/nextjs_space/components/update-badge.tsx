'use client';

import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

interface UpdateBadgeProps {
  lxcId: string;
  onCheckUpdates?: () => void;
}

export default function UpdateBadge({ lxcId, onCheckUpdates }: UpdateBadgeProps) {
  const [updateCount, setUpdateCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  
  useEffect(() => {
    fetchUpdates();
  }, [lxcId]);
  
  const fetchUpdates = async () => {
    try {
      const response = await fetch(`/api/docker/updates?lxcId=${lxcId}`);
      const data = await response.json();
      
      if (data?.success) {
        setUpdateCount(data.availableUpdates || 0);
      }
    } catch (err) {
      console.error('Erreur fetch updates:', err);
    } finally {
      setLoading(false);
    }
  };
  
  const checkUpdates = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setChecking(true);
    
    try {
      const response = await fetch('/api/docker/updates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lxcId }),
      });
      
      const data = await response.json();
      
      if (data?.success) {
        await fetchUpdates();
        onCheckUpdates?.();
      }
    } catch (err) {
      console.error('Erreur check updates:', err);
    } finally {
      setChecking(false);
    }
  };
  
  if (loading) {
    return (
      <span className="text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" />
      </span>
    );
  }
  
  if (updateCount > 0) {
    return (
      <motion.button
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        onClick={checkUpdates}
        disabled={checking}
        className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-500 text-xs hover:bg-orange-500/30 transition-colors"
        title={`${updateCount} mise(s) à jour - Cliquer pour vérifier`}
      >
        {checking ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <AlertTriangle className="h-3 w-3" />
        )}
        <span>{updateCount}</span>
      </motion.button>
    );
  }
  
  return (
    <motion.button
      initial={{ scale: 0.8 }}
      animate={{ scale: 1 }}
      onClick={checkUpdates}
      disabled={checking}
      className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/20 text-green-500 text-xs hover:bg-green-500/30 transition-colors"
      title="Tout est à jour - Cliquer pour vérifier"
    >
      {checking ? (
        <Loader2 className="h-3 w-3 animate-spin" />
      ) : (
        <CheckCircle className="h-3 w-3" />
      )}
    </motion.button>
  );
}
