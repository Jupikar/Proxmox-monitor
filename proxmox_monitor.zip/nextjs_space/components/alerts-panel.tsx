'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import {
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle,
  X,
  Bell,
  ChevronDown,
  ChevronUp,
  Clock,
  Settings,
  Loader2,
  RefreshCw,
} from 'lucide-react';

interface Alert {
  id: string;
  type: string;
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  lxcName?: string;
  value?: number;
  threshold?: number;
  acknowledged: boolean;
  createdAt: string;
}

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [counts, setCounts] = useState({ critical: 0, warning: 0, info: 0, total: 0 });
  const [loading, setLoading] = useState(true);
  const [checking, setChecking] = useState(false);
  const [expanded, setExpanded] = useState(false);
  
  const fetchAlerts = useCallback(async () => {
    try {
      const response = await fetch('/api/alerts');
      const data = await response.json();
      
      if (data?.success) {
        setAlerts(data.alerts || []);
        setCounts(data.counts || { critical: 0, warning: 0, info: 0, total: 0 });
      }
    } catch (error) {
      console.error('Erreur chargement alertes:', error);
    } finally {
      setLoading(false);
    }
  }, []);
  
  useEffect(() => {
    fetchAlerts();
    
    // Rafraîchir toutes les 30 secondes
    const interval = setInterval(fetchAlerts, 30000);
    return () => clearInterval(interval);
  }, [fetchAlerts]);
  
  const checkAlerts = async () => {
    setChecking(true);
    try {
      await fetch('/api/alerts/check', { method: 'POST' });
      await fetchAlerts();
    } catch (error) {
      console.error('Erreur vérification alertes:', error);
    } finally {
      setChecking(false);
    }
  };
  
  const acknowledgeAlert = async (id: string) => {
    try {
      await fetch('/api/alerts', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, action: 'acknowledge' }),
      });
      await fetchAlerts();
    } catch (error) {
      console.error('Erreur acquittement:', error);
    }
  };
  
  const resolveAlert = async (id: string) => {
    try {
      await fetch('/api/alerts', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, action: 'resolve' }),
      });
      await fetchAlerts();
    } catch (error) {
      console.error('Erreur résolution:', error);
    }
  };
  
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-orange-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };
  
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'border-red-500/50 bg-red-500/10';
      case 'warning':
        return 'border-orange-500/50 bg-orange-500/10';
      default:
        return 'border-blue-500/50 bg-blue-500/10';
    }
  };
  
  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours}h`;
    return `Il y a ${diffDays}j`;
  };
  
  if (loading) {
    return (
      <div className="rounded-lg bg-card p-4 shadow-md">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Loader2 className="h-5 w-5 animate-spin" />
          <span>Chargement des alertes...</span>
        </div>
      </div>
    );
  }
  
  const hasAlerts = counts.total > 0;
  const hasCritical = counts.critical > 0;
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className={`rounded-lg p-4 shadow-md border ${
        hasCritical
          ? 'bg-red-500/10 border-red-500/30'
          : hasAlerts
          ? 'bg-orange-500/10 border-orange-500/30'
          : 'bg-green-500/10 border-green-500/30'
      }`}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {hasCritical ? (
            <div className="p-2 rounded-full bg-red-500/20 animate-pulse">
              <AlertCircle className="h-5 w-5 text-red-500" />
            </div>
          ) : hasAlerts ? (
            <div className="p-2 rounded-full bg-orange-500/20">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
            </div>
          ) : (
            <div className="p-2 rounded-full bg-green-500/20">
              <CheckCircle className="h-5 w-5 text-green-500" />
            </div>
          )}
          
          <div>
            <h3 className="font-semibold">
              {hasCritical
                ? `${counts.critical} alerte(s) critique(s) !`
                : hasAlerts
                ? `${counts.total} alerte(s) active(s)`
                : 'Aucune alerte'}
            </h3>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              {counts.critical > 0 && (
                <span className="text-red-500">{counts.critical} critique</span>
              )}
              {counts.warning > 0 && (
                <span className="text-orange-500">{counts.warning} warning</span>
              )}
              {counts.info > 0 && (
                <span className="text-blue-500">{counts.info} info</span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={checkAlerts}
            disabled={checking}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Vérifier les alertes"
          >
            {checking ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RefreshCw className="h-4 w-4" />
            )}
          </button>
          
          <Link
            href="/alerts"
            className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            title="Configurer les alertes"
          >
            <Settings className="h-4 w-4" />
          </Link>
          
          {hasAlerts && (
            <button
              onClick={() => setExpanded(!expanded)}
              className="p-1.5 rounded-lg hover:bg-muted transition-colors"
            >
              {expanded ? (
                <ChevronUp className="h-5 w-5" />
              ) : (
                <ChevronDown className="h-5 w-5" />
              )}
            </button>
          )}
        </div>
      </div>
      
      <AnimatePresence>
        {expanded && hasAlerts && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="mt-4 space-y-2">
              {alerts.slice(0, 5).map((alert) => (
                <div
                  key={alert.id}
                  className={`flex items-center justify-between p-3 rounded-lg border ${getSeverityColor(alert.severity)} ${
                    alert.acknowledged ? 'opacity-60' : ''
                  }`}
                >
                  <div className="flex items-center gap-3">
                    {getSeverityIcon(alert.severity)}
                    <div>
                      <p className="font-medium text-sm">{alert.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {alert.message}
                      </p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                        <Clock className="h-3 w-3" />
                        {formatTime(alert.createdAt)}
                        {alert.acknowledged && ' • Acquittée'}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1">
                    {!alert.acknowledged && (
                      <button
                        onClick={() => acknowledgeAlert(alert.id)}
                        className="p-1.5 rounded hover:bg-muted transition-colors"
                        title="Acquitter"
                      >
                        <CheckCircle className="h-4 w-4" />
                      </button>
                    )}
                    <button
                      onClick={() => resolveAlert(alert.id)}
                      className="p-1.5 rounded hover:bg-muted transition-colors"
                      title="Résoudre"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
              
              {alerts.length > 5 && (
                <Link
                  href="/alerts"
                  className="block text-center text-sm text-primary hover:underline py-2"
                >
                  Voir toutes les alertes ({alerts.length})
                </Link>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
