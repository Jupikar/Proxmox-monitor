'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  Save,
  X,
  Loader2,
  FileText,
  AlertCircle,
  Check,
} from 'lucide-react';

interface FileEditorProps {
  lxcId: string;
  filePath: string | null;
  onClose: () => void;
}

export default function FileEditor({ lxcId, filePath, onClose }: FileEditorProps) {
  const [content, setContent] = useState('');
  const [originalContent, setOriginalContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  
  const hasChanges = content !== originalContent;
  
  const loadFile = useCallback(async () => {
    if (!filePath) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/ssh/file', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lxcId, path: filePath }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data?.error || 'Erreur de chargement');
      }
      
      setContent(data?.content || '');
      setOriginalContent(data?.content || '');
      
    } catch (err: any) {
      setError(err?.message || 'Erreur de chargement du fichier');
    } finally {
      setLoading(false);
    }
  }, [lxcId, filePath]);
  
  useEffect(() => {
    if (filePath) {
      loadFile();
    }
  }, [filePath, loadFile]);
  
  const handleSave = async () => {
    if (!filePath || saving) return;
    
    setSaving(true);
    setError(null);
    setSaved(false);
    
    try {
      const response = await fetch('/api/ssh/file', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lxcId, path: filePath, content }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data?.error || 'Erreur de sauvegarde');
      }
      
      setOriginalContent(content);
      setSaved(true);
      
      setTimeout(() => setSaved(false), 2000);
      
    } catch (err: any) {
      setError(err?.message || 'Erreur de sauvegarde');
    } finally {
      setSaving(false);
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
      e.preventDefault();
      handleSave();
    }
  };
  
  const getFileLanguage = (path: string) => {
    const ext = path.split('.').pop()?.toLowerCase();
    switch (ext) {
      case 'js':
      case 'jsx':
        return 'javascript';
      case 'ts':
      case 'tsx':
        return 'typescript';
      case 'py':
        return 'python';
      case 'sh':
      case 'bash':
        return 'bash';
      case 'json':
        return 'json';
      case 'yml':
      case 'yaml':
        return 'yaml';
      case 'md':
        return 'markdown';
      case 'css':
        return 'css';
      case 'html':
        return 'html';
      case 'xml':
        return 'xml';
      default:
        return 'text';
    }
  };
  
  if (!filePath) {
    return (
      <div className="h-full flex items-center justify-center bg-[#1e1e1e] rounded-lg">
        <div className="text-center text-gray-500">
          <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p>Sélectionnez un fichier pour l'éditer</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-full flex flex-col bg-[#1e1e1e] rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 bg-[#2d2d2d] border-b border-[#3d3d3d]">
        <div className="flex items-center gap-2 overflow-hidden">
          <FileText className="h-4 w-4 text-blue-500 flex-shrink-0" />
          <span className="text-sm text-gray-300 truncate" title={filePath}>
            {filePath}
          </span>
          {hasChanges && (
            <span className="w-2 h-2 rounded-full bg-yellow-500 flex-shrink-0" title="Modifications non sauvegardées" />
          )}
        </div>
        
        <div className="flex items-center gap-2">
          {saved && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="flex items-center gap-1 text-green-500 text-sm"
            >
              <Check className="h-4 w-4" />
              Sauvegardé
            </motion.div>
          )}
          
          <button
            onClick={handleSave}
            disabled={saving || !hasChanges}
            className="flex items-center gap-1 px-3 py-1 rounded bg-green-600 hover:bg-green-700 text-white text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            title="Sauvegarder (Ctrl+S)"
          >
            {saving ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            Sauvegarder
          </button>
          
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#3d3d3d] rounded transition-colors"
            title="Fermer"
          >
            <X className="h-4 w-4 text-gray-400" />
          </button>
        </div>
      </div>
      
      {/* Content */}
      {loading ? (
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-gray-500" />
        </div>
      ) : error ? (
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
          <p className="text-red-500 text-center">{error}</p>
          <button
            onClick={loadFile}
            className="mt-4 px-4 py-2 rounded bg-blue-600 hover:bg-blue-700 text-white text-sm transition-colors"
          >
            Réessayer
          </button>
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* Line numbers */}
          <div className="bg-[#252526] text-gray-500 text-sm font-mono py-2 px-2 text-right select-none overflow-hidden">
            {content.split('\n').map((_, i) => (
              <div key={i} className="leading-6">
                {i + 1}
              </div>
            ))}
          </div>
          
          {/* Editor */}
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            onKeyDown={handleKeyDown}
            className="flex-1 bg-transparent text-gray-200 font-mono text-sm p-2 resize-none outline-none leading-6"
            spellCheck={false}
            wrap="off"
          />
        </div>
      )}
      
      {/* Status bar */}
      <div className="flex items-center justify-between px-4 py-1 bg-[#007acc] text-white text-xs">
        <span>{getFileLanguage(filePath)}</span>
        <span>
          {content.split('\n').length} lignes
          {hasChanges && ' • Modifié'}
        </span>
      </div>
    </div>
  );
}
