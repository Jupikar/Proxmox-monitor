'use client';

import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Folder,
  FolderOpen,
  File,
  FileText,
  FileCode,
  FileJson,
  Image,
  ChevronRight,
  ChevronDown,
  Loader2,
  Link as LinkIcon,
  Upload,
  Download,
  MoreVertical,
  RefreshCw,
} from 'lucide-react';

interface FileInfo {
  name: string;
  type: 'file' | 'directory' | 'link';
  size: number;
  permissions: string;
  modified: string;
  path: string;
}

interface FileTreeProps {
  lxcId: string;
  onFileSelect: (path: string) => void;
  selectedFile: string | null;
}

interface TreeNode {
  info: FileInfo;
  children: TreeNode[] | null;
  isLoading: boolean;
  isExpanded: boolean;
}

export default function FileTree({ lxcId, onFileSelect, selectedFile }: FileTreeProps) {
  const [tree, setTree] = useState<TreeNode[]>([]);
  const [currentPath, setCurrentPath] = useState('/');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; node: TreeNode } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const loadDirectory = async (path: string): Promise<FileInfo[]> => {
    const response = await fetch('/api/ssh/files', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lxcId, path }),
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data?.error || 'Erreur de chargement');
    }
    
    return data?.files || [];
  };
  
  const loadRoot = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const files = await loadDirectory('/');
      setTree(files.map(f => ({
        info: f,
        children: null,
        isLoading: false,
        isExpanded: false,
      })));
      setCurrentPath('/');
    } catch (err: any) {
      setError(err?.message || 'Erreur de chargement');
    } finally {
      setLoading(false);
    }
  };
  
  // Upload de fichier
  const handleUpload = async (files: FileList, targetPath: string) => {
    if (files.length === 0) return;
    
    setUploading(true);
    setUploadProgress(`Upload de ${files.length} fichier(s)...`);
    
    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        setUploadProgress(`Upload ${i + 1}/${files.length}: ${file.name}`);
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('lxcId', lxcId);
        formData.append('targetPath', targetPath);
        
        const response = await fetch('/api/ssh/upload', {
          method: 'POST',
          body: formData,
        });
        
        const result = await response.json();
        
        if (!response.ok) {
          throw new Error(result?.error || 'Erreur upload');
        }
      }
      
      setUploadProgress('Upload terminé !');
      setTimeout(() => {
        setUploadProgress(null);
        loadRoot(); // Rafraîchir l'arborescence
      }, 1500);
      
    } catch (err: any) {
      setUploadProgress(`Erreur: ${err?.message}`);
      setTimeout(() => setUploadProgress(null), 3000);
    } finally {
      setUploading(false);
    }
  };
  
  // Téléchargement de fichier
  const handleDownload = async (filePath: string, fileName: string) => {
    try {
      setUploadProgress(`Téléchargement de ${fileName}...`);
      
      const response = await fetch('/api/ssh/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lxcId, path: filePath }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error?.error || 'Erreur téléchargement');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      setUploadProgress('Téléchargement terminé !');
      setTimeout(() => setUploadProgress(null), 1500);
      
    } catch (err: any) {
      setUploadProgress(`Erreur: ${err?.message}`);
      setTimeout(() => setUploadProgress(null), 3000);
    }
  };
  
  // Gestion du menu contextuel
  const handleContextMenu = (e: React.MouseEvent, node: TreeNode) => {
    e.preventDefault();
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      node,
    });
  };
  
  const closeContextMenu = () => {
    setContextMenu(null);
  };
  
  const toggleDirectory = async (node: TreeNode, path: string[]) => {
    if (node.info.type !== 'directory') return;
    
    const updateTree = (nodes: TreeNode[], pathIndex: number): TreeNode[] => {
      return nodes.map(n => {
        if (n.info.path === node.info.path) {
          if (n.isExpanded) {
            return { ...n, isExpanded: false };
          } else {
            return { ...n, isLoading: true };
          }
        }
        if (n.children && pathIndex < path.length - 1) {
          return { ...n, children: updateTree(n.children, pathIndex + 1) };
        }
        return n;
      });
    };
    
    if (!node.isExpanded) {
      setTree(prev => updateTree(prev, 0));
      
      try {
        const files = await loadDirectory(node.info.path);
        const children = files.map(f => ({
          info: f,
          children: null,
          isLoading: false,
          isExpanded: false,
        }));
        
        const setChildren = (nodes: TreeNode[]): TreeNode[] => {
          return nodes.map(n => {
            if (n.info.path === node.info.path) {
              return { ...n, children, isLoading: false, isExpanded: true };
            }
            if (n.children) {
              return { ...n, children: setChildren(n.children) };
            }
            return n;
          });
        };
        
        setTree(prev => setChildren(prev));
      } catch (err) {
        const setError = (nodes: TreeNode[]): TreeNode[] => {
          return nodes.map(n => {
            if (n.info.path === node.info.path) {
              return { ...n, isLoading: false };
            }
            if (n.children) {
              return { ...n, children: setError(n.children) };
            }
            return n;
          });
        };
        
        setTree(prev => setError(prev));
      }
    } else {
      setTree(prev => updateTree(prev, 0));
    }
  };
  
  const getFileIcon = (file: FileInfo) => {
    if (file.type === 'directory') {
      return null; // Géré séparément
    }
    
    if (file.type === 'link') {
      return <LinkIcon className="h-4 w-4 text-purple-500" />;
    }
    
    const ext = file.name.split('.').pop()?.toLowerCase();
    
    switch (ext) {
      case 'js':
      case 'ts':
      case 'jsx':
      case 'tsx':
      case 'py':
      case 'sh':
      case 'bash':
        return <FileCode className="h-4 w-4 text-green-500" />;
      case 'json':
        return <FileJson className="h-4 w-4 text-yellow-500" />;
      case 'md':
      case 'txt':
      case 'log':
        return <FileText className="h-4 w-4 text-blue-500" />;
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
      case 'svg':
        return <Image className="h-4 w-4 text-pink-500" />;
      default:
        return <File className="h-4 w-4 text-gray-500" />;
    }
  };
  
  const renderNode = (node: TreeNode, depth: number = 0) => {
    const isDirectory = node.info.type === 'directory';
    const isSelected = selectedFile === node.info.path;
    
    return (
      <div key={node.info.path}>
        <div
          className={`group flex items-center gap-1 py-1 px-2 cursor-pointer hover:bg-muted/50 rounded transition-colors ${
            isSelected ? 'bg-primary/20 text-primary' : ''
          }`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={() => {
            if (isDirectory) {
              toggleDirectory(node, []);
            } else {
              onFileSelect(node.info.path);
            }
          }}
          onContextMenu={(e) => handleContextMenu(e, node)}
        >
          {isDirectory ? (
            <>
              {node.isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              ) : node.isExpanded ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
              {node.isExpanded ? (
                <FolderOpen className="h-4 w-4 text-yellow-500" />
              ) : (
                <Folder className="h-4 w-4 text-yellow-500" />
              )}
            </>
          ) : (
            <>
              <span className="w-4" />
              {getFileIcon(node.info)}
            </>
          )}
          <span className="flex-1 text-sm truncate" title={node.info.name}>
            {node.info.name}
          </span>
          
          {/* Boutons d'action au survol */}
          <div className="hidden group-hover:flex items-center gap-1">
            {!isDirectory && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleDownload(node.info.path, node.info.name);
                }}
                className="p-1 hover:bg-muted rounded"
                title="Télécharger"
              >
                <Download className="h-3 w-3" />
              </button>
            )}
            {isDirectory && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setCurrentPath(node.info.path);
                  fileInputRef.current?.click();
                }}
                className="p-1 hover:bg-muted rounded"
                title="Upload vers ce dossier"
              >
                <Upload className="h-3 w-3" />
              </button>
            )}
          </div>
        </div>
        
        <AnimatePresence>
          {isDirectory && node.isExpanded && node.children && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="overflow-hidden"
            >
              {node.children.map(child => renderNode(child, depth + 1))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };
  
  // Charger la racine au montage si pas déjà chargé
  if (tree.length === 0 && !loading && !error && lxcId) {
    loadRoot();
  }
  
  return (
    <div className="h-full flex flex-col" onClick={closeContextMenu}>
      {/* Input caché pour l'upload */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files) {
            handleUpload(e.target.files, currentPath);
            e.target.value = ''; // Reset pour permettre de re-sélectionner le même fichier
          }
        }}
      />
      
      <div className="p-2 border-b flex items-center justify-between gap-2">
        <span className="text-sm font-medium">Fichiers</span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => {
              setCurrentPath('/');
              fileInputRef.current?.click();
            }}
            disabled={uploading}
            className="p-1.5 hover:bg-muted rounded transition-colors text-green-600"
            title="Upload vers la racine"
          >
            <Upload className="h-4 w-4" />
          </button>
          <button
            onClick={loadRoot}
            disabled={loading}
            className="p-1.5 hover:bg-muted rounded transition-colors"
            title="Rafraîchir"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>
      
      {/* Barre de progression */}
      {uploadProgress && (
        <div className="px-2 py-1 bg-blue-500/10 border-b text-xs text-blue-600 flex items-center gap-2">
          <Loader2 className="h-3 w-3 animate-spin" />
          <span>{uploadProgress}</span>
        </div>
      )}
      
      <div className="flex-1 overflow-y-auto">
        {loading && tree.length === 0 ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <div className="p-4 text-center text-red-500 text-sm">
            {error}
          </div>
        ) : tree.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground text-sm">
            Aucun fichier
          </div>
        ) : (
          <div className="py-1">
            {tree.map(node => renderNode(node, 0))}
          </div>
        )}
      </div>
      
      {/* Menu contextuel */}
      {contextMenu && (
        <div
          className="fixed z-50 bg-card border rounded-lg shadow-lg py-1 min-w-[160px]"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()}
        >
          {contextMenu.node.info.type === 'directory' ? (
            <>
              <button
                className="w-full px-3 py-2 text-left text-sm hover:bg-muted flex items-center gap-2"
                onClick={() => {
                  setCurrentPath(contextMenu.node.info.path);
                  fileInputRef.current?.click();
                  closeContextMenu();
                }}
              >
                <Upload className="h-4 w-4" />
                Upload vers ce dossier
              </button>
              <button
                className="w-full px-3 py-2 text-left text-sm hover:bg-muted flex items-center gap-2"
                onClick={() => {
                  toggleDirectory(contextMenu.node, []);
                  closeContextMenu();
                }}
              >
                <Folder className="h-4 w-4" />
                {contextMenu.node.isExpanded ? 'Replier' : 'Déplier'}
              </button>
            </>
          ) : (
            <>
              <button
                className="w-full px-3 py-2 text-left text-sm hover:bg-muted flex items-center gap-2"
                onClick={() => {
                  handleDownload(contextMenu.node.info.path, contextMenu.node.info.name);
                  closeContextMenu();
                }}
              >
                <Download className="h-4 w-4" />
                Télécharger
              </button>
              <button
                className="w-full px-3 py-2 text-left text-sm hover:bg-muted flex items-center gap-2"
                onClick={() => {
                  onFileSelect(contextMenu.node.info.path);
                  closeContextMenu();
                }}
              >
                <FileText className="h-4 w-4" />
                Ouvrir dans l'éditeur
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
