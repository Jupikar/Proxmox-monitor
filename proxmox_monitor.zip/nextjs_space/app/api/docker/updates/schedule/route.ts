import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

const CRON_COMMENT = '# proxmox-monitor-docker-updates';

interface SSHCredentials {
  host: string;
  port: number;
  username: string;
  password?: string;
  privateKey?: string;
}

function executeSSHCommand(credentials: SSHCredentials, command: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          return reject(err);
        }
        
        let output = '';
        let errorOutput = '';
        
        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });
        
        stream.stderr.on('data', (data: Buffer) => {
          errorOutput += data.toString();
        });
        
        stream.on('close', () => {
          conn.end();
          resolve(output);
        });
      });
    });
    
    conn.on('error', (err) => {
      reject(err);
    });
    
    conn.connect({
      host: credentials.host,
      port: credentials.port,
      username: credentials.username,
      password: credentials.password,
      privateKey: credentials.privateKey,
      readyTimeout: 10000,
    });
  });
}

// GET - Récupérer la configuration actuelle du cron
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const lxcId = searchParams.get('lxcId');
    
    if (!lxcId) {
      return NextResponse.json(
        { error: 'lxcId requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    const credentials: SSHCredentials = {
      host: lxc.ipAddress,
      port: lxc.sshPort,
      username: lxc.sshUsername,
      password: lxc.sshPassword || undefined,
      privateKey: lxc.sshKey || undefined,
    };
    
    // Lire le crontab actuel
    const crontab = await executeSSHCommand(credentials, 'crontab -l 2>/dev/null || echo ""');
    
    // Chercher notre ligne de cron
    const lines = crontab.split('\n');
    let schedule = null;
    let enabled = false;
    
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].includes(CRON_COMMENT.replace('# ', ''))) {
        // La ligne suivante ou celle-ci contient le cron
        const cronLine = lines[i].startsWith('#') ? lines[i] : lines[i - 1]?.includes(CRON_COMMENT) ? lines[i] : null;
        if (cronLine && !cronLine.startsWith('#')) {
          // Extraire la planification (5 premiers champs)
          const parts = cronLine.trim().split(/\s+/);
          if (parts.length >= 5) {
            schedule = parts.slice(0, 5).join(' ');
            enabled = true;
          }
        }
      }
    }
    
    // Si pas trouvé avec commentaire, chercher directement la commande
    for (const line of lines) {
      if (line.includes('/api/docker/updates/check-all') && !line.startsWith('#')) {
        const parts = line.trim().split(/\s+/);
        if (parts.length >= 5) {
          schedule = parts.slice(0, 5).join(' ');
          enabled = true;
          break;
        }
      }
    }
    
    return NextResponse.json({
      success: true,
      lxcId,
      lxcName: lxc.name,
      schedule,
      enabled,
    });
    
  } catch (error: any) {
    console.error('Erreur lecture cron:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// POST - Configurer ou supprimer le cron
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { lxcId, schedule, enabled, appUrl } = body;
    
    if (!lxcId) {
      return NextResponse.json(
        { error: 'lxcId requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    const credentials: SSHCredentials = {
      host: lxc.ipAddress,
      port: lxc.sshPort,
      username: lxc.sshUsername,
      password: lxc.sshPassword || undefined,
      privateKey: lxc.sshKey || undefined,
    };
    
    // Lire le crontab actuel
    let crontab = await executeSSHCommand(credentials, 'crontab -l 2>/dev/null || echo ""');
    
    // Supprimer les anciennes entrées (commentaire + ligne suivante si elle contient notre URL)
    let lines = crontab.split('\n').filter(line => line.trim() !== '');
    const newLines: string[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      // Ignorer notre commentaire
      if (line.includes(CRON_COMMENT.replace('# ', ''))) {
        continue;
      }
      // Ignorer les lignes avec notre URL
      if (line.includes('/api/docker/updates/check-all')) {
        continue;
      }
      newLines.push(line);
    }
    
    // Ajouter la nouvelle entrée si enabled
    if (enabled && schedule) {
      const baseUrl = appUrl || process.env.NEXTAUTH_URL || 'http://localhost:3000';
      const cronCommand = `${schedule} curl -s -X POST ${baseUrl}/api/docker/updates/check-all > /dev/null 2>&1 ${CRON_COMMENT}`;
      newLines.push(cronCommand);
    }
    
    // Mettre à jour le crontab
    const newCrontab = newLines.join('\n');
    
    if (newCrontab.trim()) {
      // Écrire le nouveau crontab
      const escapedCrontab = newCrontab.replace(/'/g, "'\\''");
      await executeSSHCommand(credentials, `echo '${escapedCrontab}' | crontab -`);
    } else {
      // Supprimer le crontab si vide
      await executeSSHCommand(credentials, 'crontab -r 2>/dev/null || true');
    }
    
    return NextResponse.json({
      success: true,
      message: enabled ? 'Vérification automatique configurée' : 'Vérification automatique désactivée',
      schedule: enabled ? schedule : null,
    });
    
  } catch (error: any) {
    console.error('Erreur configuration cron:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}
