import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Vérifier les mises à jour pour tous les LXC
export async function POST() {
  try {
    const lxcs = await prisma.lXCConfig.findMany();
    
    if (lxcs.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'Aucun LXC configuré',
        results: [],
      });
    }
    
    const results = [];
    let totalUpdates = 0;
    
    for (const lxc of lxcs) {
      try {
        // Appeler l'API de vérification pour chaque LXC
        const response = await fetch(`${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/docker/updates`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ lxcId: lxc.id }),
        });
        
        const data = await response.json();
        
        if (data?.success) {
          totalUpdates += data.updates || 0;
          results.push({
            lxcId: lxc.id,
            lxcName: lxc.name,
            checked: data.checked,
            updates: data.updates,
          });
        }
        
      } catch (err: any) {
        console.error(`Erreur vérification LXC ${lxc.name}:`, err?.message);
        results.push({
          lxcId: lxc.id,
          lxcName: lxc.name,
          error: err?.message,
        });
      }
    }
    
    return NextResponse.json({
      success: true,
      totalUpdates,
      results,
      checkedAt: new Date().toISOString(),
    });
    
  } catch (error: any) {
    console.error('Erreur vérification globale:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Récupérer le résumé des mises à jour
export async function GET() {
  try {
    const updates = await prisma.dockerImageUpdate.findMany({
      where: { hasUpdate: true },
    });
    
    const lxcs = await prisma.lXCConfig.findMany();
    const lxcMap = new Map(lxcs.map(l => [l.id, l.name]));
    
    // Grouper par LXC
    const byLxc: { [key: string]: any[] } = {};
    
    updates.forEach(u => {
      const lxcName = lxcMap.get(u.lxcId) || u.lxcId;
      if (!byLxc[lxcName]) {
        byLxc[lxcName] = [];
      }
      byLxc[lxcName].push(u);
    });
    
    // Dernière vérification
    const lastCheck = await prisma.dockerImageUpdate.findFirst({
      orderBy: { lastChecked: 'desc' },
      select: { lastChecked: true },
    });
    
    return NextResponse.json({
      success: true,
      totalUpdates: updates.length,
      byLxc,
      lastChecked: lastCheck?.lastChecked || null,
    });
    
  } catch (error: any) {
    console.error('Erreur récupération résumé:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}
