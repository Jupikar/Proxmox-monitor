import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

interface ImageInfo {
  containerName: string;
  imageName: string;
  imageTag: string;
  currentDigest: string | null;
}

// Récupérer le statut des mises à jour
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const lxcId = searchParams.get('lxcId');
    
    const whereClause: any = {};
    if (lxcId) {
      whereClause.lxcId = lxcId;
    }
    
    const updates = await prisma.dockerImageUpdate.findMany({
      where: whereClause,
      orderBy: { lastChecked: 'desc' },
    });
    
    // Compter les mises à jour disponibles
    const availableUpdates = updates.filter(u => u.hasUpdate).length;
    
    return NextResponse.json({
      success: true,
      updates,
      availableUpdates,
      totalImages: updates.length,
    });
    
  } catch (error: any) {
    console.error('Erreur récupération mises à jour:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Vérifier les mises à jour pour un LXC
export async function POST(request: NextRequest) {
  try {
    const { lxcId } = await request.json();
    
    if (!lxcId) {
      return NextResponse.json(
        { error: 'lxcId requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    // Récupérer les infos des conteneurs via SSH
    const containerImages = await getContainerImages(lxc);
    
    if (!containerImages || containerImages.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'Aucun conteneur Docker trouvé',
        checked: 0,
        updates: 0,
      });
    }
    
    let updatesFound = 0;
    const results = [];
    
    for (const container of containerImages) {
      try {
        // Vérifier si une mise à jour est disponible
        const updateInfo = await checkImageUpdate(lxc, container);
        
        // Sauvegarder ou mettre à jour dans la base
        const saved = await prisma.dockerImageUpdate.upsert({
          where: {
            lxcId_containerName: {
              lxcId: lxc.id,
              containerName: container.containerName,
            },
          },
          create: {
            lxcId: lxc.id,
            containerName: container.containerName,
            imageName: container.imageName,
            currentTag: container.imageTag,
            currentDigest: container.currentDigest,
            latestDigest: updateInfo.latestDigest,
            hasUpdate: updateInfo.hasUpdate,
            lastChecked: new Date(),
          },
          update: {
            imageName: container.imageName,
            currentTag: container.imageTag,
            currentDigest: container.currentDigest,
            latestDigest: updateInfo.latestDigest,
            hasUpdate: updateInfo.hasUpdate,
            lastChecked: new Date(),
          },
        });
        
        if (updateInfo.hasUpdate) {
          updatesFound++;
        }
        
        results.push(saved);
        
      } catch (err: any) {
        console.error(`Erreur vérification ${container.containerName}:`, err?.message);
      }
    }
    
    return NextResponse.json({
      success: true,
      checked: containerImages.length,
      updates: updatesFound,
      results,
    });
    
  } catch (error: any) {
    console.error('Erreur vérification mises à jour:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Récupérer les images des conteneurs via SSH
async function getContainerImages(lxc: any): Promise<ImageInfo[]> {
  return new Promise((resolve) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      // Commande pour récupérer les infos des conteneurs
      const cmd = `docker ps -a --format '{{.Names}}|{{.Image}}' 2>/dev/null`;
      
      conn.exec(cmd, (err, stream) => {
        if (err) {
          conn.end();
          resolve([]);
          return;
        }
        
        let output = '';
        
        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });
        
        stream.on('close', async () => {
          const containers: ImageInfo[] = [];
          const lines = output.trim().split('\n').filter(l => l);
          
          for (const line of lines) {
            const [name, image] = line.split('|');
            if (name && image) {
              // Extraire le nom et le tag de l'image
              let imageName = image;
              let imageTag = 'latest';
              
              if (image.includes(':')) {
                const parts = image.split(':');
                imageTag = parts.pop() || 'latest';
                imageName = parts.join(':');
              }
              
              // Récupérer le digest local
              const digest = await getLocalDigest(conn, image);
              
              containers.push({
                containerName: name,
                imageName,
                imageTag,
                currentDigest: digest,
              });
            }
          }
          
          conn.end();
          resolve(containers);
        });
      });
    });
    
    conn.on('error', () => {
      resolve([]);
    });
    
    const connConfig: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort,
      username: lxc.sshUsername,
      readyTimeout: 10000,
    };
    
    if (lxc.sshPassword) {
      connConfig.password = lxc.sshPassword;
    } else if (lxc.sshKey) {
      connConfig.privateKey = lxc.sshKey;
    }
    
    conn.connect(connConfig);
  });
}

// Récupérer le digest local d'une image
function getLocalDigest(conn: Client, image: string): Promise<string | null> {
  return new Promise((resolve) => {
    const cmd = `docker inspect --format='{{index .RepoDigests 0}}' ${image} 2>/dev/null || echo ''`;
    
    conn.exec(cmd, (err, stream) => {
      if (err) {
        resolve(null);
        return;
      }
      
      let output = '';
      
      stream.on('data', (data: Buffer) => {
        output += data.toString();
      });
      
      stream.on('close', () => {
        const digest = output.trim();
        // Extraire juste le sha256:...
        if (digest && digest.includes('@')) {
          resolve(digest.split('@')[1] || null);
        } else if (digest && digest.startsWith('sha256:')) {
          resolve(digest);
        } else {
          resolve(null);
        }
      });
    });
  });
}

// Vérifier si une mise à jour est disponible
async function checkImageUpdate(lxc: any, container: ImageInfo): Promise<{ hasUpdate: boolean; latestDigest: string | null }> {
  // Essayer de récupérer le digest distant via l'API du registry
  try {
    const remoteDigest = await getRemoteDigest(container.imageName, container.imageTag);
    
    if (remoteDigest && container.currentDigest) {
      const hasUpdate = remoteDigest !== container.currentDigest;
      return { hasUpdate, latestDigest: remoteDigest };
    }
    
    // Si on n'a pas pu comparer les digests, utiliser docker pull pour vérifier
    return await checkWithDockerPull(lxc, container);
    
  } catch (err) {
    // Fallback: utiliser docker pull
    return await checkWithDockerPull(lxc, container);
  }
}

// Récupérer le digest distant depuis Docker Hub
async function getRemoteDigest(imageName: string, tag: string): Promise<string | null> {
  try {
    // Déterminer si c'est une image officielle (library/) ou non
    let repository = imageName;
    if (!imageName.includes('/')) {
      repository = `library/${imageName}`;
    }
    
    // Obtenir un token anonyme
    const tokenResponse = await fetch(
      `https://auth.docker.io/token?service=registry.docker.io&scope=repository:${repository}:pull`,
      { cache: 'no-store' }
    );
    
    if (!tokenResponse.ok) {
      return null;
    }
    
    const tokenData = await tokenResponse.json();
    const token = tokenData.token;
    
    // Récupérer le manifest
    const manifestResponse = await fetch(
      `https://registry-1.docker.io/v2/${repository}/manifests/${tag}`,
      {
        headers: {
          'Accept': 'application/vnd.docker.distribution.manifest.v2+json, application/vnd.oci.image.manifest.v1+json',
          'Authorization': `Bearer ${token}`,
        },
        cache: 'no-store',
      }
    );
    
    if (!manifestResponse.ok) {
      return null;
    }
    
    // Le digest est dans le header Docker-Content-Digest
    const digest = manifestResponse.headers.get('docker-content-digest');
    return digest;
    
  } catch (err) {
    console.error('Erreur récupération digest distant:', err);
    return null;
  }
}

// Vérifier via docker pull (fallback)
function checkWithDockerPull(lxc: any, container: ImageInfo): Promise<{ hasUpdate: boolean; latestDigest: string | null }> {
  return new Promise((resolve) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      const image = `${container.imageName}:${container.imageTag}`;
      // Utiliser docker pull pour vérifier sans télécharger tout (juste le manifest)
      const cmd = `docker pull ${image} 2>&1 | tail -5`;
      
      conn.exec(cmd, (err, stream) => {
        if (err) {
          conn.end();
          resolve({ hasUpdate: false, latestDigest: null });
          return;
        }
        
        let output = '';
        
        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });
        
        stream.on('close', async () => {
          conn.end();
          
          // Vérifier si l'image a été mise à jour
          const hasUpdate = output.includes('Downloaded newer image') || 
                           output.includes('Pull complete') ||
                           output.includes('Pulling from');
          
          // Si mise à jour, essayer de récupérer le nouveau digest
          // (on laisse null car le pull a déjà mis à jour)
          
          // En fait, si "Image is up to date", pas de mise à jour
          const isUpToDate = output.includes('Image is up to date');
          
          resolve({ 
            hasUpdate: !isUpToDate && hasUpdate,
            latestDigest: null 
          });
        });
      });
    });
    
    conn.on('error', () => {
      resolve({ hasUpdate: false, latestDigest: null });
    });
    
    const connConfig: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort,
      username: lxc.sshUsername,
      readyTimeout: 30000, // Plus long pour le pull
    };
    
    if (lxc.sshPassword) {
      connConfig.password = lxc.sshPassword;
    } else if (lxc.sshKey) {
      connConfig.privateKey = lxc.sshKey;
    }
    
    conn.connect(connConfig);
  });
}
