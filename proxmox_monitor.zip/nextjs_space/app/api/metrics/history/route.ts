import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Récupérer l'historique des métriques
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const lxcId = searchParams.get('lxcId');
    const period = searchParams.get('period') || '24h'; // 1h, 6h, 24h, 7d, 30d
    
    // Calculer la date de début selon la période
    const now = new Date();
    let startDate: Date;
    
    switch (period) {
      case '1h':
        startDate = new Date(now.getTime() - 60 * 60 * 1000);
        break;
      case '6h':
        startDate = new Date(now.getTime() - 6 * 60 * 60 * 1000);
        break;
      case '24h':
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
        break;
      case '7d':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '30d':
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
        break;
      default:
        startDate = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    }
    
    const whereClause: any = {
      timestamp: {
        gte: startDate,
      },
    };
    
    if (lxcId) {
      whereClause.lxcId = lxcId;
    }
    
    const metrics = await prisma.metricsHistory.findMany({
      where: whereClause,
      orderBy: { timestamp: 'asc' },
      include: {
        lxc: {
          select: {
            name: true,
            proxmoxId: true,
          },
        },
      },
    });
    
    // Agréger les données si nécessaire (pour les longues périodes)
    let aggregatedMetrics = metrics;
    
    if (period === '7d' || period === '30d') {
      // Agréger par heure pour 7d, par jour pour 30d
      const intervalMs = period === '7d' ? 60 * 60 * 1000 : 24 * 60 * 60 * 1000;
      aggregatedMetrics = aggregateMetrics(metrics, intervalMs);
    }
    
    return NextResponse.json({
      success: true,
      metrics: aggregatedMetrics,
      period,
      startDate: startDate.toISOString(),
      endDate: now.toISOString(),
    });
    
  } catch (error) {
    console.error('Erreur récupération historique:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la récupération de l\'historique' },
      { status: 500 }
    );
  }
}

// Collecter les métriques (appelé périodiquement)
export async function POST() {
  try {
    const config = await prisma.proxmoxConfig.findFirst();
    
    if (!config) {
      return NextResponse.json(
        { error: 'Proxmox non configuré' },
        { status: 400 }
      );
    }
    
    const lxcs = await prisma.lXCConfig.findMany();
    
    if (lxcs.length === 0) {
      return NextResponse.json(
        { error: 'Aucun LXC configuré' },
        { status: 400 }
      );
    }
    
    // Importer dynamiquement pour éviter les problèmes de SSR
    const { ProxmoxAPI } = await import('@/lib/proxmox-api');
    
    const api = new ProxmoxAPI({
      url: config.url,
      username: config.username,
      token: config.token,
    });
    
    const nodes = await api.getNodes();
    const nodeName = nodes[0]?.node || 'pve';
    
    const savedMetrics = [];
    
    for (const lxc of lxcs) {
      try {
        const status = await api.getLXCStatus(nodeName, lxc.proxmoxId);
        
        if (status) {
          const metric = await prisma.metricsHistory.create({
            data: {
              lxcId: lxc.id,
              cpu: (status.cpu || 0) * 100,
              memory: status.maxmem ? ((status.mem || 0) / status.maxmem) * 100 : 0,
              memoryUsed: status.mem || 0,
              memoryMax: status.maxmem || 0,
              disk: status.maxdisk ? ((status.disk || 0) / status.maxdisk) * 100 : 0,
              diskUsed: status.disk || 0,
              diskMax: status.maxdisk || 0,
              netIn: status.netin || 0,
              netOut: status.netout || 0,
              status: status.status || 'unknown',
            },
          });
          
          savedMetrics.push(metric);
        }
      } catch (err) {
        console.error(`Erreur collecte métriques LXC ${lxc.proxmoxId}:`, err);
      }
    }
    
    // Nettoyer les anciennes métriques (plus de 30 jours)
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    await prisma.metricsHistory.deleteMany({
      where: {
        timestamp: {
          lt: thirtyDaysAgo,
        },
      },
    });
    
    return NextResponse.json({
      success: true,
      collected: savedMetrics.length,
      timestamp: new Date().toISOString(),
    });
    
  } catch (error) {
    console.error('Erreur collecte métriques:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la collecte des métriques' },
      { status: 500 }
    );
  }
}

function aggregateMetrics(metrics: any[], intervalMs: number): any[] {
  if (metrics.length === 0) return [];
  
  const buckets: { [key: string]: any[] } = {};
  
  metrics.forEach(metric => {
    const timestamp = new Date(metric.timestamp).getTime();
    const bucketKey = Math.floor(timestamp / intervalMs) * intervalMs;
    const key = `${metric.lxcId}-${bucketKey}`;
    
    if (!buckets[key]) {
      buckets[key] = [];
    }
    buckets[key].push(metric);
  });
  
  return Object.entries(buckets).map(([key, items]) => {
    const [lxcId, bucketTime] = key.split('-');
    const avgMetric = {
      id: key,
      lxcId: items[0].lxcId,
      lxc: items[0].lxc,
      timestamp: new Date(parseInt(bucketTime)),
      cpu: items.reduce((sum, m) => sum + m.cpu, 0) / items.length,
      memory: items.reduce((sum, m) => sum + m.memory, 0) / items.length,
      memoryUsed: items.reduce((sum, m) => sum + m.memoryUsed, 0) / items.length,
      memoryMax: items[0].memoryMax,
      disk: items.reduce((sum, m) => sum + m.disk, 0) / items.length,
      diskUsed: items.reduce((sum, m) => sum + m.diskUsed, 0) / items.length,
      diskMax: items[0].diskMax,
      netIn: items.reduce((sum, m) => sum + m.netIn, 0) / items.length,
      netOut: items.reduce((sum, m) => sum + m.netOut, 0) / items.length,
      status: items[items.length - 1].status,
    };
    
    return avgMetric;
  }).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
}
