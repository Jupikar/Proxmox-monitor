import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { ProxmoxAPI } from '@/lib/proxmox-api';

const prisma = new PrismaClient();

export async function GET() {
  try {
    // Récupérer la configuration Proxmox
    const config = await prisma.proxmoxConfig.findFirst();
    
    if (!config) {
      return NextResponse.json(
        { error: 'Proxmox non configuré. Veuillez d\'abord configurer la connexion Proxmox.' },
        { status: 400 }
      );
    }
    
    const api = new ProxmoxAPI({
      url: config.url,
      username: config.username,
      token: config.token,
    });
    
    // Récupérer la liste des nodes
    const nodes = await api.getNodes();
    
    if (!nodes || nodes.length === 0) {
      return NextResponse.json(
        { error: 'Aucun node Proxmox trouvé' },
        { status: 404 }
      );
    }
    
    // Récupérer tous les LXC de tous les nodes
    const allLxcs: any[] = [];
    
    for (const node of nodes) {
      const nodeName = node.node;
      const lxcList = await api.getLXCList(nodeName);
      
      for (const lxc of lxcList) {
        // Récupérer les détails de configuration du LXC pour obtenir l'IP
        let ipAddress = '';
        try {
          const configResponse = await fetch(
            `${config.url}/api2/json/nodes/${nodeName}/lxc/${lxc.vmid}/config`,
            {
              headers: {
                'Authorization': `PVEAPIToken=${config.username}=${config.token}`,
              },
            }
          );
          
          // Utiliser l'API Proxmox directement pour obtenir la config
          const https = await import('https');
          const axios = (await import('axios')).default;
          
          const client = axios.create({
            baseURL: config.url,
            headers: {
              'Authorization': `PVEAPIToken=${config.username}=${config.token}`,
            },
            httpsAgent: new https.Agent({
              rejectUnauthorized: false,
            }),
          });
          
          const configRes = await client.get(`/api2/json/nodes/${nodeName}/lxc/${lxc.vmid}/config`);
          const lxcConfig = configRes?.data?.data;
          
          // Essayer d'extraire l'IP depuis net0
          if (lxcConfig?.net0) {
            const net0 = lxcConfig.net0;
            const ipMatch = net0.match(/ip=([^,\/]+)/);
            if (ipMatch) {
              ipAddress = ipMatch[1];
            }
          }
        } catch (err) {
          console.error(`Erreur lors de la récupération de la config du LXC ${lxc.vmid}:`, err);
        }
        
        allLxcs.push({
          vmid: lxc.vmid,
          name: lxc.name || `LXC ${lxc.vmid}`,
          status: lxc.status,
          node: nodeName,
          ipAddress: ipAddress || '',
          maxmem: lxc.maxmem,
          maxdisk: lxc.maxdisk,
          cpus: lxc.cpus,
        });
      }
    }
    
    // Récupérer les LXC déjà configurés pour marquer lesquels sont déjà ajoutés
    const existingLxcs = await prisma.lXCConfig.findMany();
    const existingIds = new Set(existingLxcs.map(l => l.proxmoxId));
    
    const lxcsWithStatus = allLxcs.map(lxc => ({
      ...lxc,
      alreadyAdded: existingIds.has(lxc.vmid),
    }));
    
    return NextResponse.json({
      success: true,
      lxcs: lxcsWithStatus,
      total: lxcsWithStatus.length,
    });
    
  } catch (error) {
    console.error('Erreur lors du scan des LXC:', error);
    return NextResponse.json(
      { error: 'Erreur lors du scan des LXC' },
      { status: 500 }
    );
  }
}
