import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const { lxcId, path } = await request.json();
    
    if (!lxcId) {
      return NextResponse.json(
        { error: 'LXC ID requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    const targetPath = path || '/';
    const files = await listFiles(lxc, targetPath);
    
    return NextResponse.json({ success: true, files, path: targetPath });
    
  } catch (error) {
    console.error('Erreur listing fichiers:', error);
    return NextResponse.json(
      { error: 'Erreur lors de la lecture des fichiers' },
      { status: 500 }
    );
  }
}

interface FileInfo {
  name: string;
  type: 'file' | 'directory' | 'link';
  size: number;
  permissions: string;
  modified: string;
  path: string;
}

function listFiles(lxc: any, path: string): Promise<FileInfo[]> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      conn.sftp((err, sftp) => {
        if (err) {
          conn.end();
          reject(err);
          return;
        }
        
        sftp.readdir(path, (err, list) => {
          if (err) {
            conn.end();
            reject(err);
            return;
          }
          
          const files: FileInfo[] = list.map((item: any) => {
            let type: 'file' | 'directory' | 'link' = 'file';
            
            if (item.attrs.isDirectory()) {
              type = 'directory';
            } else if (item.attrs.isSymbolicLink()) {
              type = 'link';
            }
            
            const permissions = item.attrs.mode
              ? (item.attrs.mode & parseInt('777', 8)).toString(8)
              : '---';
            
            return {
              name: item.filename,
              type,
              size: item.attrs.size || 0,
              permissions,
              modified: new Date((item.attrs.mtime || 0) * 1000).toISOString(),
              path: path === '/' ? `/${item.filename}` : `${path}/${item.filename}`,
            };
          });
          
          // Trier: dossiers d'abord, puis fichiers
          files.sort((a, b) => {
            if (a.type === 'directory' && b.type !== 'directory') return -1;
            if (a.type !== 'directory' && b.type === 'directory') return 1;
            return a.name.localeCompare(b.name);
          });
          
          conn.end();
          resolve(files);
        });
      });
    });
    
    conn.on('error', (err) => {
      reject(err);
    });
    
    const config: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort || 22,
      username: lxc.sshUsername,
      readyTimeout: 10000,
    };
    
    if (lxc.sshKey) {
      config.privateKey = lxc.sshKey;
    } else if (lxc.sshPassword) {
      config.password = lxc.sshPassword;
    }
    
    conn.connect(config);
  });
}
