import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

// Lire un fichier
export async function POST(request: NextRequest) {
  try {
    const { lxcId, path } = await request.json();
    
    if (!lxcId || !path) {
      return NextResponse.json(
        { error: 'LXC ID et chemin requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    const content = await readFile(lxc, path);
    
    return NextResponse.json({ success: true, content, path });
    
  } catch (error: any) {
    console.error('Erreur lecture fichier:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur lors de la lecture du fichier' },
      { status: 500 }
    );
  }
}

// Sauvegarder un fichier
export async function PUT(request: NextRequest) {
  try {
    const { lxcId, path, content } = await request.json();
    
    if (!lxcId || !path) {
      return NextResponse.json(
        { error: 'LXC ID et chemin requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    await writeFile(lxc, path, content || '');
    
    return NextResponse.json({ success: true, message: 'Fichier sauvegardé' });
    
  } catch (error: any) {
    console.error('Erreur écriture fichier:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur lors de l\'écriture du fichier' },
      { status: 500 }
    );
  }
}

function readFile(lxc: any, path: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      conn.sftp((err, sftp) => {
        if (err) {
          conn.end();
          reject(err);
          return;
        }
        
        const chunks: Buffer[] = [];
        const readStream = sftp.createReadStream(path);
        
        readStream.on('data', (chunk: Buffer) => {
          chunks.push(chunk);
        });
        
        readStream.on('end', () => {
          conn.end();
          const content = Buffer.concat(chunks).toString('utf8');
          resolve(content);
        });
        
        readStream.on('error', (err: Error) => {
          conn.end();
          reject(err);
        });
      });
    });
    
    conn.on('error', (err) => {
      reject(err);
    });
    
    const config: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort || 22,
      username: lxc.sshUsername,
      readyTimeout: 10000,
    };
    
    if (lxc.sshKey) {
      config.privateKey = lxc.sshKey;
    } else if (lxc.sshPassword) {
      config.password = lxc.sshPassword;
    }
    
    conn.connect(config);
  });
}

function writeFile(lxc: any, path: string, content: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    
    conn.on('ready', () => {
      conn.sftp((err, sftp) => {
        if (err) {
          conn.end();
          reject(err);
          return;
        }
        
        const writeStream = sftp.createWriteStream(path);
        
        writeStream.on('close', () => {
          conn.end();
          resolve();
        });
        
        writeStream.on('error', (err: Error) => {
          conn.end();
          reject(err);
        });
        
        writeStream.write(content);
        writeStream.end();
      });
    });
    
    conn.on('error', (err) => {
      reject(err);
    });
    
    const config: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort || 22,
      username: lxc.sshUsername,
      readyTimeout: 10000,
    };
    
    if (lxc.sshKey) {
      config.privateKey = lxc.sshKey;
    } else if (lxc.sshPassword) {
      config.password = lxc.sshPassword;
    }
    
    conn.connect(config);
  });
}
