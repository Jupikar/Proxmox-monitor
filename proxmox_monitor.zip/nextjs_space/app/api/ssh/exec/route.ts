import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const { lxcId, command } = await request.json();
    
    if (!lxcId || !command) {
      return NextResponse.json(
        { error: 'LXC ID et commande requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouvé' },
        { status: 404 }
      );
    }
    
    const output = await executeSSHCommand(lxc, command);
    
    return NextResponse.json({ success: true, output });
    
  } catch (error) {
    console.error('Erreur exécution SSH:', error);
    return NextResponse.json(
      { error: 'Erreur lors de l\'exécution de la commande' },
      { status: 500 }
    );
  }
}

function executeSSHCommand(lxc: any, command: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const conn = new Client();
    let output = '';
    
    conn.on('ready', () => {
      conn.exec(command, (err, stream) => {
        if (err) {
          conn.end();
          reject(err);
          return;
        }
        
        stream.on('close', () => {
          conn.end();
          resolve(output);
        });
        
        stream.on('data', (data: Buffer) => {
          output += data.toString();
        });
        
        stream.stderr.on('data', (data: Buffer) => {
          output += data.toString();
        });
      });
    });
    
    conn.on('error', (err) => {
      reject(err);
    });
    
    const config: any = {
      host: lxc.ipAddress,
      port: lxc.sshPort || 22,
      username: lxc.sshUsername,
      readyTimeout: 10000,
    };
    
    if (lxc.sshKey) {
      config.privateKey = lxc.sshKey;
    } else if (lxc.sshPassword) {
      config.password = lxc.sshPassword;
    }
    
    conn.connect(config);
  });
}
