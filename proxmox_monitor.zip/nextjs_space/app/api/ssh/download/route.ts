import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const { lxcId, path } = await request.json();
    
    if (!lxcId || !path) {
      return NextResponse.json(
        { error: 'lxcId et path requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouv\u00e9' },
        { status: 404 }
      );
    }
    
    return new Promise<NextResponse>((resolve) => {
      const conn = new Client();
      
      conn.on('ready', () => {
        conn.sftp((err, sftp) => {
          if (err) {
            conn.end();
            resolve(
              NextResponse.json(
                { error: `Erreur SFTP: ${err.message}` },
                { status: 500 }
              )
            );
            return;
          }
          
          // R\u00e9cup\u00e9rer les infos du fichier
          sftp.stat(path, (statErr, stats) => {
            if (statErr) {
              conn.end();
              resolve(
                NextResponse.json(
                  { error: `Fichier non trouv\u00e9: ${statErr.message}` },
                  { status: 404 }
                )
              );
              return;
            }
            
            if (stats.isDirectory()) {
              conn.end();
              resolve(
                NextResponse.json(
                  { error: 'Impossible de t\u00e9l\u00e9charger un dossier' },
                  { status: 400 }
                )
              );
              return;
            }
            
            const chunks: Buffer[] = [];
            const readStream = sftp.createReadStream(path);
            
            readStream.on('data', (chunk: Buffer) => {
              chunks.push(chunk);
            });
            
            readStream.on('end', () => {
              conn.end();
              const buffer = Buffer.concat(chunks);
              const fileName = path.split('/').pop() || 'file';
              
              resolve(
                new NextResponse(buffer, {
                  headers: {
                    'Content-Type': 'application/octet-stream',
                    'Content-Disposition': `attachment; filename="${fileName}"`,
                    'Content-Length': buffer.length.toString(),
                  },
                })
              );
            });
            
            readStream.on('error', (readErr: Error) => {
              conn.end();
              resolve(
                NextResponse.json(
                  { error: `Erreur lecture: ${readErr.message}` },
                  { status: 500 }
                )
              );
            });
          });
        });
      });
      
      conn.on('error', (connErr) => {
        resolve(
          NextResponse.json(
            { error: `Erreur connexion SSH: ${connErr.message}` },
            { status: 500 }
          )
        );
      });
      
      const connConfig: any = {
        host: lxc.ipAddress,
        port: lxc.sshPort,
        username: lxc.sshUsername,
        readyTimeout: 10000,
      };
      
      if (lxc.sshPassword) {
        connConfig.password = lxc.sshPassword;
      } else if (lxc.sshKey) {
        connConfig.privateKey = lxc.sshKey;
      }
      
      conn.connect(connConfig);
    });
    
  } catch (error: any) {
    console.error('Erreur download:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur lors du t\u00e9l\u00e9chargement' },
      { status: 500 }
    );
  }
}
