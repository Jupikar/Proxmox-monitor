import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { Client } from 'ssh2';

const prisma = new PrismaClient();

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const lxcId = formData.get('lxcId') as string;
    const targetPath = formData.get('targetPath') as string;
    
    if (!file || !lxcId || !targetPath) {
      return NextResponse.json(
        { error: 'Fichier, lxcId et targetPath requis' },
        { status: 400 }
      );
    }
    
    const lxc = await prisma.lXCConfig.findUnique({
      where: { id: lxcId },
    });
    
    if (!lxc) {
      return NextResponse.json(
        { error: 'LXC non trouv\u00e9' },
        { status: 404 }
      );
    }
    
    // Convertir le fichier en Buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Construire le chemin complet
    const fullPath = targetPath.endsWith('/')
      ? `${targetPath}${file.name}`
      : `${targetPath}/${file.name}`;
    
    return new Promise<NextResponse>((resolve) => {
      const conn = new Client();
      
      conn.on('ready', () => {
        conn.sftp((err, sftp) => {
          if (err) {
            conn.end();
            resolve(
              NextResponse.json(
                { error: `Erreur SFTP: ${err.message}` },
                { status: 500 }
              )
            );
            return;
          }
          
          const writeStream = sftp.createWriteStream(fullPath);
          
          writeStream.on('close', () => {
            conn.end();
            resolve(
              NextResponse.json({
                success: true,
                message: 'Fichier upload\u00e9 avec succ\u00e8s',
                path: fullPath,
                size: buffer.length,
              })
            );
          });
          
          writeStream.on('error', (writeErr: Error) => {
            conn.end();
            resolve(
              NextResponse.json(
                { error: `Erreur \u00e9criture: ${writeErr.message}` },
                { status: 500 }
              )
            );
          });
          
          writeStream.end(buffer);
        });
      });
      
      conn.on('error', (connErr) => {
        resolve(
          NextResponse.json(
            { error: `Erreur connexion SSH: ${connErr.message}` },
            { status: 500 }
          )
        );
      });
      
      const connConfig: any = {
        host: lxc.ipAddress,
        port: lxc.sshPort,
        username: lxc.sshUsername,
        readyTimeout: 10000,
      };
      
      if (lxc.sshPassword) {
        connConfig.password = lxc.sshPassword;
      } else if (lxc.sshKey) {
        connConfig.privateKey = lxc.sshKey;
      }
      
      conn.connect(connConfig);
    });
    
  } catch (error: any) {
    console.error('Erreur upload:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur lors de l\'upload' },
      { status: 500 }
    );
  }
}
