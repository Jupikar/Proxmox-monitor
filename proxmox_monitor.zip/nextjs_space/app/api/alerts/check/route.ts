import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface MetricData {
  lxcId: string;
  lxcName: string;
  cpu: number;
  memory: number;
  disk: number;
  status: string;
}

// Vérifier les alertes et créer si nécessaire
export async function POST() {
  try {
    const configs = await prisma.alertConfig.findMany({
      where: { enabled: true },
    });
    
    if (configs.length === 0) {
      return NextResponse.json({
        success: true,
        message: 'Aucune alerte configurée',
        created: 0,
      });
    }
    
    const lxcs = await prisma.lXCConfig.findMany();
    const alertsCreated: any[] = [];
    
    // Récupérer les métriques récentes pour chaque LXC
    for (const lxc of lxcs) {
      // Vérifier les alertes pour ce LXC
      for (const config of configs) {
        // Si l'alerte est liée à un LXC spécifique et que ce n'est pas celui-ci, passer
        if (config.lxcId && config.lxcId !== lxc.id) continue;
        
        const alert = await checkAlertCondition(config, lxc);
        if (alert) {
          alertsCreated.push(alert);
        }
      }
    }
    
    // Vérifier les alertes de mises à jour (globales)
    const updateConfigs = configs.filter(c => c.type === 'updates_available');
    for (const config of updateConfigs) {
      const alert = await checkUpdatesAlert(config);
      if (alert) alertsCreated.push(alert);
    }
    
    // Envoyer les notifications pour les nouvelles alertes
    if (alertsCreated.length > 0) {
      await sendNotifications(alertsCreated);
    }
    
    return NextResponse.json({
      success: true,
      created: alertsCreated.length,
      alerts: alertsCreated,
    });
    
  } catch (error: any) {
    console.error('Erreur vérification alertes:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

async function checkAlertCondition(config: any, lxc: any) {
  // Récupérer les métriques récentes (selon la durée configurée)
  const sinceDate = new Date(Date.now() - config.duration * 60 * 1000);
  
  const metrics = await prisma.metricsHistory.findMany({
    where: {
      lxcId: lxc.id,
      timestamp: { gte: sinceDate },
    },
    orderBy: { timestamp: 'desc' },
  });
  
  if (metrics.length === 0) return null;
  
  let shouldAlert = false;
  let value = 0;
  let title = '';
  let message = '';
  let severity: 'info' | 'warning' | 'critical' = 'warning';
  
  switch (config.type) {
    case 'cpu_high': {
      // Vérifier si le CPU est au-dessus du seuil sur la durée
      const avgCpu = metrics.reduce((sum, m) => sum + m.cpu, 0) / metrics.length;
      const allAbove = metrics.every(m => m.cpu >= config.threshold);
      
      if (allAbove && metrics.length >= 2) {
        shouldAlert = true;
        value = avgCpu;
        title = `CPU élevé sur ${lxc.name}`;
        message = `CPU à ${avgCpu.toFixed(1)}% (seuil: ${config.threshold}%) depuis ${config.duration} min`;
        severity = avgCpu >= 95 ? 'critical' : 'warning';
      }
      break;
    }
    
    case 'memory_high': {
      const avgMem = metrics.reduce((sum, m) => sum + m.memory, 0) / metrics.length;
      const allAbove = metrics.every(m => m.memory >= config.threshold);
      
      if (allAbove && metrics.length >= 2) {
        shouldAlert = true;
        value = avgMem;
        title = `Mémoire élevée sur ${lxc.name}`;
        message = `RAM à ${avgMem.toFixed(1)}% (seuil: ${config.threshold}%) depuis ${config.duration} min`;
        severity = avgMem >= 95 ? 'critical' : 'warning';
      }
      break;
    }
    
    case 'disk_full': {
      const latestDisk = metrics[0]?.disk || 0;
      
      if (latestDisk >= config.threshold) {
        shouldAlert = true;
        value = latestDisk;
        title = `Disque presque plein sur ${lxc.name}`;
        message = `Disque à ${latestDisk.toFixed(1)}% (seuil: ${config.threshold}%)`;
        severity = latestDisk >= 95 ? 'critical' : 'warning';
      }
      break;
    }
    
    case 'lxc_down': {
      const latestStatus = metrics[0]?.status;
      
      if (latestStatus && latestStatus !== 'running') {
        shouldAlert = true;
        value = 0;
        title = `LXC arrêté: ${lxc.name}`;
        message = `Le conteneur LXC ${lxc.name} (${lxc.proxmoxId}) est arrêté`;
        severity = 'critical';
      }
      break;
    }
  }
  
  if (!shouldAlert) return null;
  
  // Vérifier si une alerte similaire existe déjà (non résolue)
  const existingAlert = await prisma.alert.findFirst({
    where: {
      type: config.type,
      lxcId: lxc.id,
      resolvedAt: null,
    },
  });
  
  if (existingAlert) return null; // Alerte déjà active
  
  // Créer l'alerte
  const alert = await prisma.alert.create({
    data: {
      type: config.type,
      severity,
      title,
      message,
      lxcId: lxc.id,
      lxcName: lxc.name,
      value,
      threshold: config.threshold,
    },
  });
  
  return alert;
}

async function checkUpdatesAlert(config: any) {
  const updates = await prisma.dockerImageUpdate.findMany({
    where: { hasUpdate: true },
  });
  
  if (updates.length < config.threshold) return null;
  
  // Vérifier si une alerte existe déjà
  const existingAlert = await prisma.alert.findFirst({
    where: {
      type: 'updates_available',
      resolvedAt: null,
    },
  });
  
  if (existingAlert) return null;
  
  const alert = await prisma.alert.create({
    data: {
      type: 'updates_available',
      severity: 'info',
      title: `${updates.length} mise(s) à jour disponible(s)`,
      message: `Il y a ${updates.length} conteneur(s) Docker avec des mises à jour disponibles`,
      value: updates.length,
      threshold: config.threshold,
    },
  });
  
  return alert;
}

async function sendNotifications(alerts: any[]) {
  try {
    const notifConfigs = await prisma.notificationConfig.findMany({
      where: { enabled: true },
    });
    
    for (const notifConfig of notifConfigs) {
      const config = JSON.parse(notifConfig.config);
      const allowedTypes = notifConfig.alertTypes === 'all' 
        ? null 
        : notifConfig.alertTypes.split(',');
      
      for (const alert of alerts) {
        // Vérifier si le type d'alerte est autorisé
        if (allowedTypes && !allowedTypes.includes(alert.type)) continue;
        
        // Vérifier la sévérité minimale
        const severityOrder = ['info', 'warning', 'critical'];
        if (severityOrder.indexOf(alert.severity) < severityOrder.indexOf(notifConfig.minSeverity)) continue;
        
        if (notifConfig.type === 'webhook' && config.webhook_url) {
          await sendWebhook(config.webhook_url, alert);
        } else if (notifConfig.type === 'email' && config.email) {
          await sendEmail(config, alert);
        }
        
        // Marquer l'alerte comme notifiée
        await prisma.alert.update({
          where: { id: alert.id },
          data: { notifiedAt: new Date() },
        });
      }
    }
  } catch (error) {
    console.error('Erreur envoi notifications:', error);
  }
}

async function sendWebhook(url: string, alert: any) {
  try {
    await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: alert.type,
        severity: alert.severity,
        title: alert.title,
        message: alert.message,
        lxcName: alert.lxcName,
        value: alert.value,
        threshold: alert.threshold,
        timestamp: alert.createdAt,
      }),
    });
  } catch (error) {
    console.error('Erreur webhook:', error);
  }
}

async function sendEmail(config: any, alert: any) {
  // Utiliser un service SMTP ou une API email
  // Pour l'instant, on log juste
  console.log(`[EMAIL] To: ${config.email}`);
  console.log(`[EMAIL] Subject: [${alert.severity.toUpperCase()}] ${alert.title}`);
  console.log(`[EMAIL] Body: ${alert.message}`);
  
  // Si SMTP est configuré
  if (config.smtp_host && config.smtp_port) {
    // Implémentation SMTP à ajouter
  }
}
