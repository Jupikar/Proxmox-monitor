import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Récupérer les configurations de notifications
export async function GET() {
  try {
    const configs = await prisma.notificationConfig.findMany({
      orderBy: { createdAt: 'asc' },
    });
    
    // Masquer les infos sensibles
    const safeConfigs = configs.map(c => {
      const config = JSON.parse(c.config);
      return {
        ...c,
        config: {
          ...config,
          smtp_password: config.smtp_password ? '******' : undefined,
        },
      };
    });
    
    return NextResponse.json({
      success: true,
      configs: safeConfigs,
    });
    
  } catch (error: any) {
    console.error('Erreur récupération configs notifications:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Créer/modifier une configuration de notification
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, type, enabled, config, alertTypes, minSeverity } = body;
    
    if (!type || !config) {
      return NextResponse.json(
        { error: 'Type et config requis' },
        { status: 400 }
      );
    }
    
    const configJson = JSON.stringify(config);
    
    let notifConfig;
    
    if (id) {
      // Mise à jour - récupérer l'ancienne config pour préserver le mot de passe si non fourni
      const existing = await prisma.notificationConfig.findUnique({ where: { id } });
      let finalConfig = config;
      
      if (existing && config.smtp_password === '******') {
        const oldConfig = JSON.parse(existing.config);
        finalConfig = { ...config, smtp_password: oldConfig.smtp_password };
      }
      
      notifConfig = await prisma.notificationConfig.update({
        where: { id },
        data: {
          type,
          enabled: enabled ?? true,
          config: JSON.stringify(finalConfig),
          alertTypes: alertTypes || 'all',
          minSeverity: minSeverity || 'warning',
        },
      });
    } else {
      // Création
      notifConfig = await prisma.notificationConfig.create({
        data: {
          type,
          enabled: enabled ?? true,
          config: configJson,
          alertTypes: alertTypes || 'all',
          minSeverity: minSeverity || 'warning',
        },
      });
    }
    
    return NextResponse.json({
      success: true,
      config: notifConfig,
    });
    
  } catch (error: any) {
    console.error('Erreur sauvegarde config notification:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Supprimer une configuration
export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json();
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requis' },
        { status: 400 }
      );
    }
    
    await prisma.notificationConfig.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
    
  } catch (error: any) {
    console.error('Erreur suppression config notification:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Tester une notification
export async function PUT(request: NextRequest) {
  try {
    const { type, config } = await request.json();
    
    const testAlert = {
      type: 'test',
      severity: 'info',
      title: 'Test de notification',
      message: 'Ceci est un test de notification depuis Proxmox Monitor',
      lxcName: 'Test LXC',
      value: 50,
      threshold: 80,
      createdAt: new Date().toISOString(),
    };
    
    if (type === 'webhook' && config.webhook_url) {
      const response = await fetch(config.webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testAlert),
      });
      
      if (!response.ok) {
        throw new Error(`Webhook a retourné ${response.status}`);
      }
      
      return NextResponse.json({
        success: true,
        message: 'Webhook envoyé avec succès',
      });
    } else if (type === 'email' && config.email) {
      // Pour le test email, on simule
      console.log(`[TEST EMAIL] To: ${config.email}`);
      console.log(`[TEST EMAIL] Subject: [TEST] ${testAlert.title}`);
      
      return NextResponse.json({
        success: true,
        message: `Email de test simulé vers ${config.email}`,
      });
    }
    
    return NextResponse.json(
      { error: 'Configuration invalide' },
      { status: 400 }
    );
    
  } catch (error: any) {
    console.error('Erreur test notification:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur lors du test' },
      { status: 500 }
    );
  }
}
