import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Récupérer les alertes actives
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const includeResolved = searchParams.get('includeResolved') === 'true';
    const limit = parseInt(searchParams.get('limit') || '50');
    
    const whereClause: any = {};
    
    if (!includeResolved) {
      whereClause.resolvedAt = null;
    }
    
    const alerts = await prisma.alert.findMany({
      where: whereClause,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    
    // Compter par sévérité
    const critical = alerts.filter(a => a.severity === 'critical' && !a.resolvedAt).length;
    const warning = alerts.filter(a => a.severity === 'warning' && !a.resolvedAt).length;
    const info = alerts.filter(a => a.severity === 'info' && !a.resolvedAt).length;
    
    return NextResponse.json({
      success: true,
      alerts,
      counts: { critical, warning, info, total: critical + warning + info },
    });
    
  } catch (error: any) {
    console.error('Erreur récupération alertes:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Acquitter ou résoudre une alerte
export async function PUT(request: NextRequest) {
  try {
    const { id, action } = await request.json();
    
    if (!id || !action) {
      return NextResponse.json(
        { error: 'ID et action requis' },
        { status: 400 }
      );
    }
    
    let updateData: any = {};
    
    if (action === 'acknowledge') {
      updateData.acknowledged = true;
    } else if (action === 'resolve') {
      updateData.resolvedAt = new Date();
    }
    
    const alert = await prisma.alert.update({
      where: { id },
      data: updateData,
    });
    
    return NextResponse.json({
      success: true,
      alert,
    });
    
  } catch (error: any) {
    console.error('Erreur mise à jour alerte:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Supprimer une alerte (historique)
export async function DELETE(request: NextRequest) {
  try {
    const { id, clearAll } = await request.json();
    
    if (clearAll) {
      // Supprimer toutes les alertes résolues
      await prisma.alert.deleteMany({
        where: { resolvedAt: { not: null } },
      });
    } else if (id) {
      await prisma.alert.delete({
        where: { id },
      });
    } else {
      return NextResponse.json(
        { error: 'ID ou clearAll requis' },
        { status: 400 }
      );
    }
    
    return NextResponse.json({ success: true });
    
  } catch (error: any) {
    console.error('Erreur suppression alerte:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}
