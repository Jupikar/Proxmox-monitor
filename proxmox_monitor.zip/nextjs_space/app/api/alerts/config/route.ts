import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Types d'alertes disponibles
const ALERT_TYPES = [
  { id: 'cpu_high', name: 'CPU élevé', description: 'CPU au-dessus du seuil pendant une durée', defaultThreshold: 80, unit: '%' },
  { id: 'memory_high', name: 'Mémoire élevée', description: 'RAM au-dessus du seuil pendant une durée', defaultThreshold: 85, unit: '%' },
  { id: 'disk_full', name: 'Disque plein', description: 'Espace disque au-dessus du seuil', defaultThreshold: 90, unit: '%' },
  { id: 'lxc_down', name: 'LXC arrêté', description: 'Conteneur LXC non accessible', defaultThreshold: 0, unit: '' },
  { id: 'container_down', name: 'Conteneur Docker arrêté', description: 'Un conteneur Docker s\'est arrêté', defaultThreshold: 0, unit: '' },
  { id: 'updates_available', name: 'Mises à jour disponibles', description: 'Des mises à jour Docker sont disponibles', defaultThreshold: 1, unit: '' },
  { id: 'ssh_failed', name: 'Connexion SSH échouée', description: 'Impossible de se connecter en SSH', defaultThreshold: 0, unit: '' },
];

// Récupérer les configurations d'alertes
export async function GET() {
  try {
    const configs = await prisma.alertConfig.findMany({
      orderBy: { createdAt: 'asc' },
    });
    
    const lxcs = await prisma.lXCConfig.findMany({
      select: { id: true, name: true },
    });
    
    return NextResponse.json({
      success: true,
      configs,
      alertTypes: ALERT_TYPES,
      lxcs,
    });
    
  } catch (error: any) {
    console.error('Erreur récupération configs alertes:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Créer/modifier une configuration d'alerte
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, type, enabled, threshold, duration, lxcId } = body;
    
    if (!name || !type) {
      return NextResponse.json(
        { error: 'Nom et type requis' },
        { status: 400 }
      );
    }
    
    let config;
    
    if (id) {
      // Mise à jour
      config = await prisma.alertConfig.update({
        where: { id },
        data: {
          name,
          type,
          enabled: enabled ?? true,
          threshold: threshold ?? 80,
          duration: duration ?? 5,
          lxcId: lxcId || null,
        },
      });
    } else {
      // Création
      config = await prisma.alertConfig.create({
        data: {
          name,
          type,
          enabled: enabled ?? true,
          threshold: threshold ?? 80,
          duration: duration ?? 5,
          lxcId: lxcId || null,
        },
      });
    }
    
    return NextResponse.json({
      success: true,
      config,
    });
    
  } catch (error: any) {
    console.error('Erreur sauvegarde config alerte:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}

// Supprimer une configuration
export async function DELETE(request: NextRequest) {
  try {
    const { id } = await request.json();
    
    if (!id) {
      return NextResponse.json(
        { error: 'ID requis' },
        { status: 400 }
      );
    }
    
    await prisma.alertConfig.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
    
  } catch (error: any) {
    console.error('Erreur suppression config:', error);
    return NextResponse.json(
      { error: error?.message || 'Erreur' },
      { status: 500 }
    );
  }
}
