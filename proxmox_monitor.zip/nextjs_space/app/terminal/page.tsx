'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Terminal as TerminalIcon,
  FolderTree,
  FileEdit,
  Server,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  Minimize2,
  AlertCircle,
} from 'lucide-react';
import FileTree from '@/components/file-tree';
import SSHTerminal from '@/components/ssh-terminal';
import FileEditor from '@/components/file-editor';

interface LXCConfig {
  id: string;
  proxmoxId: number;
  name: string;
  ipAddress: string;
  sshPort: number;
  sshUsername: string;
}

export default function TerminalPage() {
  const [lxcs, setLxcs] = useState<LXCConfig[]>([]);
  const [selectedLxc, setSelectedLxc] = useState<LXCConfig | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  
  // Panneaux
  const [showFileTree, setShowFileTree] = useState(true);
  const [showEditor, setShowEditor] = useState(true);
  const [activeTab, setActiveTab] = useState<'terminal' | 'editor'>('terminal');
  
  useEffect(() => {
    fetchLXCs();
  }, []);
  
  const fetchLXCs = async () => {
    try {
      const response = await fetch('/api/lxc/config');
      const data = await response.json();
      const lxcList = data?.lxcs || [];
      setLxcs(lxcList);
      
      // Sélectionner le premier LXC par défaut
      if (lxcList.length > 0 && !selectedLxc) {
        setSelectedLxc(lxcList[0]);
      }
    } catch (error) {
      console.error('Error fetching LXCs:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleFileSelect = (path: string) => {
    setSelectedFile(path);
    setActiveTab('editor');
    setShowEditor(true);
  };
  
  const handleCloseEditor = () => {
    setSelectedFile(null);
    setActiveTab('terminal');
  };
  
  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-[calc(100vh-120px)]">
        <div className="text-center">
          <TerminalIcon className="h-12 w-12 text-primary mx-auto mb-4 animate-pulse" />
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }
  
  if (lxcs.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="rounded-lg bg-card p-8 text-center">
          <AlertCircle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold mb-2">Aucun LXC configuré</h2>
          <p className="text-muted-foreground mb-4">
            Vous devez d&apos;abord configurer au moins un LXC pour utiliser le terminal.
          </p>
          <a
            href="/config"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
          >
            <Server className="h-4 w-4" />
            Aller à la configuration
          </a>
        </div>
      </div>
    );
  }
  
  return (
    <div className="h-[calc(100vh-80px)] flex flex-col">
      {/* Header avec sélecteur de LXC */}
      <div className="px-4 py-3 border-b bg-card flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <TerminalIcon className="h-5 w-5 text-primary" />
            <h1 className="text-lg font-semibold">Terminal & Fichiers</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <label className="text-sm text-muted-foreground">LXC :</label>
            <select
              value={selectedLxc?.id || ''}
              onChange={(e) => {
                const lxc = lxcs.find(l => l.id === e.target.value);
                setSelectedLxc(lxc || null);
                setSelectedFile(null);
              }}
              className="px-3 py-1.5 rounded-lg border bg-background text-sm"
            >
              {lxcs.map((lxc) => (
                <option key={lxc.id} value={lxc.id}>
                  {lxc.name} ({lxc.ipAddress})
                </option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowFileTree(!showFileTree)}
            className={`p-2 rounded-lg transition-colors ${
              showFileTree ? 'bg-primary/20 text-primary' : 'hover:bg-muted'
            }`}
            title={showFileTree ? 'Masquer les fichiers' : 'Afficher les fichiers'}
          >
            <FolderTree className="h-4 w-4" />
          </button>
          
          <button
            onClick={() => setShowEditor(!showEditor)}
            className={`p-2 rounded-lg transition-colors ${
              showEditor ? 'bg-primary/20 text-primary' : 'hover:bg-muted'
            }`}
            title={showEditor ? "Masquer l'éditeur" : "Afficher l'éditeur"}
          >
            <FileEdit className="h-4 w-4" />
          </button>
        </div>
      </div>
      
      {/* Contenu principal */}
      {selectedLxc && (
        <div className="flex-1 flex overflow-hidden">
          {/* Panneau gauche - Arborescence des fichiers */}
          {showFileTree && (
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: 280 }}
              exit={{ width: 0 }}
              className="border-r bg-card overflow-hidden flex flex-col"
              style={{ minWidth: showFileTree ? 280 : 0 }}
            >
              <FileTree
                lxcId={selectedLxc.id}
                onFileSelect={handleFileSelect}
                selectedFile={selectedFile}
              />
            </motion.div>
          )}
          
          {/* Panneau central - Terminal et Éditeur */}
          <div className="flex-1 flex flex-col overflow-hidden p-2 gap-2">
            {/* Onglets sur mobile/tablette */}
            <div className="flex gap-2 md:hidden">
              <button
                onClick={() => setActiveTab('terminal')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                  activeTab === 'terminal'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted hover:bg-muted/80'
                }`}
              >
                <TerminalIcon className="h-4 w-4" />
                Terminal
              </button>
              
              <button
                onClick={() => setActiveTab('editor')}
                className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg transition-colors ${
                  activeTab === 'editor'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted hover:bg-muted/80'
                }`}
              >
                <FileEdit className="h-4 w-4" />
                Éditeur
                {selectedFile && (
                  <span className="w-2 h-2 rounded-full bg-green-500" />
                )}
              </button>
            </div>
            
            {/* Vue desktop - Terminal et Éditeur côte à côte */}
            <div className="hidden md:flex flex-1 gap-2 overflow-hidden">
              {/* Terminal */}
              <div className={`overflow-hidden transition-all duration-300 ${
                showEditor ? 'flex-1' : 'flex-1'
              }`}>
                <SSHTerminal
                  lxcId={selectedLxc.id}
                  lxcName={selectedLxc.name}
                />
              </div>
              
              {/* Éditeur */}
              {showEditor && (
                <div className="flex-1 overflow-hidden">
                  <FileEditor
                    lxcId={selectedLxc.id}
                    filePath={selectedFile}
                    onClose={handleCloseEditor}
                  />
                </div>
              )}
            </div>
            
            {/* Vue mobile - Onglets */}
            <div className="flex-1 md:hidden overflow-hidden">
              {activeTab === 'terminal' ? (
                <SSHTerminal
                  lxcId={selectedLxc.id}
                  lxcName={selectedLxc.name}
                />
              ) : (
                <FileEditor
                  lxcId={selectedLxc.id}
                  filePath={selectedFile}
                  onClose={handleCloseEditor}
                />
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
