'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Bell,
  Plus,
  Trash2,
  Save,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Mail,
  Webhook,
  Settings,
  Loader2,
  TestTube,
  Clock,
  Cpu,
  HardDrive,
  MemoryStick,
  Server,
  Container,
  RefreshCw,
} from 'lucide-react';

interface AlertConfig {
  id?: string;
  name: string;
  type: string;
  enabled: boolean;
  threshold: number;
  duration: number;
  lxcId: string | null;
}

interface NotificationConfig {
  id?: string;
  type: 'email' | 'webhook';
  enabled: boolean;
  config: any;
  alertTypes: string;
  minSeverity: string;
}

interface AlertType {
  id: string;
  name: string;
  description: string;
  defaultThreshold: number;
  unit: string;
}

interface LXC {
  id: string;
  name: string;
}

export default function AlertsConfigPage() {
  const [alertConfigs, setAlertConfigs] = useState<AlertConfig[]>([]);
  const [notifConfigs, setNotifConfigs] = useState<NotificationConfig[]>([]);
  const [alertTypes, setAlertTypes] = useState<AlertType[]>([]);
  const [lxcs, setLxcs] = useState<LXC[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'alerts' | 'notifications'>('alerts');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  
  // Formulaires
  const [newAlert, setNewAlert] = useState<AlertConfig>({
    name: '',
    type: 'cpu_high',
    enabled: true,
    threshold: 80,
    duration: 5,
    lxcId: null,
  });
  
  const [newNotif, setNewNotif] = useState<NotificationConfig>({
    type: 'webhook',
    enabled: true,
    config: { webhook_url: '' },
    alertTypes: 'all',
    minSeverity: 'warning',
  });
  
  useEffect(() => {
    fetchData();
  }, []);
  
  const fetchData = async () => {
    setLoading(true);
    try {
      // Charger configs alertes
      const alertRes = await fetch('/api/alerts/config');
      const alertData = await alertRes.json();
      if (alertData.success) {
        setAlertConfigs(alertData.configs || []);
        setAlertTypes(alertData.alertTypes || []);
        setLxcs(alertData.lxcs || []);
      }
      
      // Charger configs notifications
      const notifRes = await fetch('/api/alerts/notifications');
      const notifData = await notifRes.json();
      if (notifData.success) {
        setNotifConfigs(notifData.configs || []);
      }
    } catch (error) {
      console.error('Erreur chargement:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const saveAlertConfig = async (config: AlertConfig) => {
    setSaving(true);
    try {
      const res = await fetch('/api/alerts/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      const data = await res.json();
      
      if (data.success) {
        setMessage({ type: 'success', text: 'Configuration sauvegardée' });
        fetchData();
        setNewAlert({
          name: '',
          type: 'cpu_high',
          enabled: true,
          threshold: 80,
          duration: 5,
          lxcId: null,
        });
      } else {
        setMessage({ type: 'error', text: data.error || 'Erreur' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur de sauvegarde' });
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };
  
  const deleteAlertConfig = async (id: string) => {
    if (!confirm('Supprimer cette configuration ?')) return;
    
    try {
      const res = await fetch('/api/alerts/config', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      
      if (data.success) {
        setMessage({ type: 'success', text: 'Configuration supprimée' });
        fetchData();
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur de suppression' });
    }
    setTimeout(() => setMessage(null), 3000);
  };
  
  const saveNotifConfig = async (config: NotificationConfig) => {
    setSaving(true);
    try {
      const res = await fetch('/api/alerts/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      const data = await res.json();
      
      if (data.success) {
        setMessage({ type: 'success', text: 'Configuration sauvegardée' });
        fetchData();
        setNewNotif({
          type: 'webhook',
          enabled: true,
          config: { webhook_url: '' },
          alertTypes: 'all',
          minSeverity: 'warning',
        });
      } else {
        setMessage({ type: 'error', text: data.error || 'Erreur' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur de sauvegarde' });
    } finally {
      setSaving(false);
      setTimeout(() => setMessage(null), 3000);
    }
  };
  
  const deleteNotifConfig = async (id: string) => {
    if (!confirm('Supprimer cette configuration ?')) return;
    
    try {
      const res = await fetch('/api/alerts/notifications', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      const data = await res.json();
      
      if (data.success) {
        setMessage({ type: 'success', text: 'Configuration supprimée' });
        fetchData();
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur de suppression' });
    }
    setTimeout(() => setMessage(null), 3000);
  };
  
  const testNotification = async (config: NotificationConfig) => {
    setTesting(config.id || 'new');
    try {
      const res = await fetch('/api/alerts/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: config.type, config: config.config }),
      });
      const data = await res.json();
      
      if (data.success) {
        setMessage({ type: 'success', text: data.message });
      } else {
        setMessage({ type: 'error', text: data.error || 'Erreur de test' });
      }
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur de test' });
    } finally {
      setTesting(null);
      setTimeout(() => setMessage(null), 3000);
    }
  };
  
  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'cpu_high': return <Cpu className="h-4 w-4" />;
      case 'memory_high': return <MemoryStick className="h-4 w-4" />;
      case 'disk_full': return <HardDrive className="h-4 w-4" />;
      case 'lxc_down': return <Server className="h-4 w-4" />;
      case 'container_down': return <Container className="h-4 w-4" />;
      case 'updates_available': return <RefreshCw className="h-4 w-4" />;
      default: return <AlertTriangle className="h-4 w-4" />;
    }
  };
  
  if (loading) {
    return (
      <div className="container mx-auto max-w-5xl px-4 py-8">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto max-w-5xl px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
          <Bell className="h-8 w-8" />
          Alertes & Notifications
        </h1>
        <p className="text-muted-foreground">
          Configurez les alertes et les canaux de notification
        </p>
      </motion.div>
      
      {message && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`mb-6 p-4 rounded-lg flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-green-500/20 text-green-600'
              : 'bg-red-500/20 text-red-600'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle className="h-5 w-5" />
          ) : (
            <XCircle className="h-5 w-5" />
          )}
          {message.text}
        </motion.div>
      )}
      
      {/* Onglets */}
      <div className="flex gap-2 mb-6">
        <button
          onClick={() => setActiveTab('alerts')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'alerts'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted hover:bg-muted/80'
          }`}
        >
          <AlertTriangle className="h-4 w-4 inline mr-2" />
          Règles d'alertes
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2 rounded-lg font-medium transition-colors ${
            activeTab === 'notifications'
              ? 'bg-primary text-primary-foreground'
              : 'bg-muted hover:bg-muted/80'
          }`}
        >
          <Bell className="h-4 w-4 inline mr-2" />
          Notifications
        </button>
      </div>
      
      {activeTab === 'alerts' ? (
        <div className="space-y-6">
          {/* Configs existantes */}
          {alertConfigs.length > 0 && (
            <div className="rounded-lg bg-card p-6 shadow-md">
              <h2 className="text-lg font-semibold mb-4">Règles configurées</h2>
              <div className="space-y-3">
                {alertConfigs.map((config) => {
                  const alertType = alertTypes.find(t => t.id === config.type);
                  const lxc = lxcs.find(l => l.id === config.lxcId);
                  
                  return (
                    <div
                      key={config.id}
                      className={`flex items-center justify-between p-4 rounded-lg border ${
                        config.enabled ? 'bg-muted/30' : 'bg-muted/10 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-full ${
                          config.enabled ? 'bg-primary/20 text-primary' : 'bg-muted'
                        }`}>
                          {getAlertIcon(config.type)}
                        </div>
                        <div>
                          <p className="font-medium">{config.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {alertType?.name || config.type}
                            {config.threshold > 0 && ` > ${config.threshold}${alertType?.unit || '%'}`}
                            {config.duration > 0 && ` pendant ${config.duration} min`}
                            {lxc && ` • ${lxc.name}`}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => saveAlertConfig({ ...config, enabled: !config.enabled })}
                          className={`p-2 rounded-lg transition-colors ${
                            config.enabled
                              ? 'bg-green-500/20 text-green-600 hover:bg-green-500/30'
                              : 'bg-muted hover:bg-muted/80'
                          }`}
                          title={config.enabled ? 'Désactiver' : 'Activer'}
                        >
                          {config.enabled ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                        </button>
                        <button
                          onClick={() => deleteAlertConfig(config.id!)}
                          className="p-2 rounded-lg bg-red-500/20 text-red-600 hover:bg-red-500/30 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
          
          {/* Nouvelle alerte */}
          <div className="rounded-lg bg-card p-6 shadow-md">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Nouvelle règle d'alerte
            </h2>
            
            <div className="grid gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Nom de l'alerte</label>
                <input
                  type="text"
                  value={newAlert.name}
                  onChange={(e) => setNewAlert({ ...newAlert, name: e.target.value })}
                  placeholder="Ex: CPU critique serveur web"
                  className="w-full px-3 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Type d'alerte</label>
                  <select
                    value={newAlert.type}
                    onChange={(e) => {
                      const type = alertTypes.find(t => t.id === e.target.value);
                      setNewAlert({
                        ...newAlert,
                        type: e.target.value,
                        threshold: type?.defaultThreshold || 80,
                      });
                    }}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  >
                    {alertTypes.map((type) => (
                      <option key={type.id} value={type.id}>
                        {type.name}
                      </option>
                    ))}
                  </select>
                  <p className="text-xs text-muted-foreground mt-1">
                    {alertTypes.find(t => t.id === newAlert.type)?.description}
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1">LXC cible</label>
                  <select
                    value={newAlert.lxcId || ''}
                    onChange={(e) => setNewAlert({ ...newAlert, lxcId: e.target.value || null })}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  >
                    <option value="">Tous les LXC</option>
                    {lxcs.map((lxc) => (
                      <option key={lxc.id} value={lxc.id}>
                        {lxc.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">
                    Seuil ({alertTypes.find(t => t.id === newAlert.type)?.unit || '%'})
                  </label>
                  <input
                    type="number"
                    value={newAlert.threshold}
                    onChange={(e) => setNewAlert({ ...newAlert, threshold: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium mb-1 flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    Durée (minutes)
                  </label>
                  <input
                    type="number"
                    value={newAlert.duration}
                    onChange={(e) => setNewAlert({ ...newAlert, duration: parseInt(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Durée pendant laquelle la condition doit être vraie
                  </p>
                </div>
              </div>
              
              <button
                onClick={() => saveAlertConfig(newAlert)}
                disabled={saving || !newAlert.name}
                className="flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Sauvegarder
              </button>
            </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Configs notifications existantes */}
          {notifConfigs.length > 0 && (
            <div className="rounded-lg bg-card p-6 shadow-md">
              <h2 className="text-lg font-semibold mb-4">Canaux configurés</h2>
              <div className="space-y-3">
                {notifConfigs.map((config) => (
                  <div
                    key={config.id}
                    className={`flex items-center justify-between p-4 rounded-lg border ${
                      config.enabled ? 'bg-muted/30' : 'bg-muted/10 opacity-60'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-full ${
                        config.enabled ? 'bg-primary/20 text-primary' : 'bg-muted'
                      }`}>
                        {config.type === 'email' ? (
                          <Mail className="h-4 w-4" />
                        ) : (
                          <Webhook className="h-4 w-4" />
                        )}
                      </div>
                      <div>
                        <p className="font-medium capitalize">{config.type}</p>
                        <p className="text-sm text-muted-foreground">
                          {config.type === 'email'
                            ? config.config.email
                            : config.config.webhook_url?.substring(0, 50) + '...'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Sévérité min: {config.minSeverity} • Types: {config.alertTypes}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => testNotification(config)}
                        disabled={testing === config.id}
                        className="p-2 rounded-lg bg-blue-500/20 text-blue-600 hover:bg-blue-500/30 transition-colors"
                        title="Tester"
                      >
                        {testing === config.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <TestTube className="h-4 w-4" />
                        )}
                      </button>
                      <button
                        onClick={() => saveNotifConfig({ ...config, enabled: !config.enabled })}
                        className={`p-2 rounded-lg transition-colors ${
                          config.enabled
                            ? 'bg-green-500/20 text-green-600 hover:bg-green-500/30'
                            : 'bg-muted hover:bg-muted/80'
                        }`}
                      >
                        {config.enabled ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                      </button>
                      <button
                        onClick={() => deleteNotifConfig(config.id!)}
                        className="p-2 rounded-lg bg-red-500/20 text-red-600 hover:bg-red-500/30 transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Nouvelle notification */}
          <div className="rounded-lg bg-card p-6 shadow-md">
            <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Nouveau canal de notification
            </h2>
            
            <div className="grid gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Type de notification</label>
                <div className="flex gap-4">
                  <button
                    onClick={() => setNewNotif({ ...newNotif, type: 'webhook', config: { webhook_url: '' } })}
                    className={`flex-1 p-4 rounded-lg border-2 transition-colors ${
                      newNotif.type === 'webhook'
                        ? 'border-primary bg-primary/10'
                        : 'border-muted hover:border-muted-foreground/50'
                    }`}
                  >
                    <Webhook className="h-6 w-6 mx-auto mb-2" />
                    <p className="font-medium">Webhook</p>
                    <p className="text-xs text-muted-foreground">Discord, Slack, etc.</p>
                  </button>
                  <button
                    onClick={() => setNewNotif({ ...newNotif, type: 'email', config: { email: '' } })}
                    className={`flex-1 p-4 rounded-lg border-2 transition-colors ${
                      newNotif.type === 'email'
                        ? 'border-primary bg-primary/10'
                        : 'border-muted hover:border-muted-foreground/50'
                    }`}
                  >
                    <Mail className="h-6 w-6 mx-auto mb-2" />
                    <p className="font-medium">Email</p>
                    <p className="text-xs text-muted-foreground">Via SMTP</p>
                  </button>
                </div>
              </div>
              
              {newNotif.type === 'webhook' ? (
                <div>
                  <label className="block text-sm font-medium mb-1">URL du Webhook</label>
                  <input
                    type="url"
                    value={newNotif.config.webhook_url || ''}
                    onChange={(e) => setNewNotif({ ...newNotif, config: { webhook_url: e.target.value } })}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Compatible Discord, Slack, et tout webhook JSON
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Email destinataire</label>
                    <input
                      type="email"
                      value={newNotif.config.email || ''}
                      onChange={(e) => setNewNotif({ 
                        ...newNotif, 
                        config: { ...newNotif.config, email: e.target.value } 
                      })}
                      placeholder="admin@example.com"
                      className="w-full px-3 py-2 rounded-lg border bg-background"
                    />
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Serveur SMTP</label>
                      <input
                        type="text"
                        value={newNotif.config.smtp_host || ''}
                        onChange={(e) => setNewNotif({ 
                          ...newNotif, 
                          config: { ...newNotif.config, smtp_host: e.target.value } 
                        })}
                        placeholder="smtp.gmail.com"
                        className="w-full px-3 py-2 rounded-lg border bg-background"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Port SMTP</label>
                      <input
                        type="number"
                        value={newNotif.config.smtp_port || 587}
                        onChange={(e) => setNewNotif({ 
                          ...newNotif, 
                          config: { ...newNotif.config, smtp_port: parseInt(e.target.value) } 
                        })}
                        className="w-full px-3 py-2 rounded-lg border bg-background"
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Utilisateur SMTP</label>
                      <input
                        type="text"
                        value={newNotif.config.smtp_user || ''}
                        onChange={(e) => setNewNotif({ 
                          ...newNotif, 
                          config: { ...newNotif.config, smtp_user: e.target.value } 
                        })}
                        placeholder="user@gmail.com"
                        className="w-full px-3 py-2 rounded-lg border bg-background"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Mot de passe SMTP</label>
                      <input
                        type="password"
                        value={newNotif.config.smtp_password || ''}
                        onChange={(e) => setNewNotif({ 
                          ...newNotif, 
                          config: { ...newNotif.config, smtp_password: e.target.value } 
                        })}
                        placeholder="••••••••"
                        className="w-full px-3 py-2 rounded-lg border bg-background"
                      />
                    </div>
                  </div>
                </div>
              )}
              
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Sévérité minimale</label>
                  <select
                    value={newNotif.minSeverity}
                    onChange={(e) => setNewNotif({ ...newNotif, minSeverity: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  >
                    <option value="info">Info (toutes)</option>
                    <option value="warning">Warning</option>
                    <option value="critical">Critical uniquement</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Types d'alertes</label>
                  <select
                    value={newNotif.alertTypes}
                    onChange={(e) => setNewNotif({ ...newNotif, alertTypes: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border bg-background"
                  >
                    <option value="all">Toutes les alertes</option>
                    <option value="cpu_high,memory_high">CPU et Mémoire</option>
                    <option value="disk_full">Disque uniquement</option>
                    <option value="lxc_down,container_down">Arrêts uniquement</option>
                  </select>
                </div>
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={() => testNotification(newNotif)}
                  disabled={testing === 'new'}
                  className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  {testing === 'new' ? <Loader2 className="h-4 w-4 animate-spin" /> : <TestTube className="h-4 w-4" />}
                  Tester
                </button>
                <button
                  onClick={() => saveNotifConfig(newNotif)}
                  disabled={saving || (!newNotif.config.webhook_url && !newNotif.config.email)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  Sauvegarder
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
