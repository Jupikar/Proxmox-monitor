'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Settings, Server, Plus, Trash2, Edit, Check, X, Search, Loader2, Monitor, CheckCircle2 } from 'lucide-react';

interface LXCConfig {
  id: string;
  proxmoxId: number;
  name: string;
  ipAddress: string;
  sshPort: number;
  sshUsername: string;
  sshPassword?: string;
  sshKey?: string;
}

interface ScannedLXC {
  vmid: number;
  name: string;
  status: string;
  node: string;
  ipAddress: string;
  maxmem: number;
  maxdisk: number;
  cpus: number;
  alreadyAdded: boolean;
}

export default function ConfigPage() {
  const [proxmoxUrl, setProxmoxUrl] = useState('');
  const [proxmoxUsername, setProxmoxUsername] = useState('');
  const [proxmoxToken, setProxmoxToken] = useState('');
  const [testingProxmox, setTestingProxmox] = useState(false);
  const [proxmoxSuccess, setProxmoxSuccess] = useState<boolean | null>(null);
  
  const [lxcs, setLxcs] = useState<LXCConfig[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // États pour le scan
  const [showScanModal, setShowScanModal] = useState(false);
  const [scanning, setScanning] = useState(false);
  const [scannedLxcs, setScannedLxcs] = useState<ScannedLXC[]>([]);
  const [selectedLxcs, setSelectedLxcs] = useState<Set<number>>(new Set());
  const [scanError, setScanError] = useState<string | null>(null);
  const [addingFromScan, setAddingFromScan] = useState(false);
  
  // État pour configurer les LXC scannés sélectionnés
  const [configuringScanned, setConfiguringScanned] = useState(false);
  const [scannedToConfig, setScannedToConfig] = useState<ScannedLXC[]>([]);
  const [scannedConfigs, setScannedConfigs] = useState<{[key: number]: {sshUsername: string; sshPassword: string; sshPort: string}}>({});
  
  const [formData, setFormData] = useState({
    proxmoxId: '',
    name: '',
    ipAddress: '',
    sshPort: '22',
    sshUsername: '',
    sshPassword: '',
    sshKey: '',
  });
  
  useEffect(() => {
    fetchProxmoxConfig();
    fetchLXCs();
  }, []);
  
  const fetchProxmoxConfig = async () => {
    try {
      const response = await fetch('/api/proxmox/config');
      const data = await response.json();
      
      if (data?.config) {
        setProxmoxUrl(data.config.url ?? '');
        setProxmoxUsername(data.config.username ?? '');
        setProxmoxToken(data.config.token ?? '');
      }
    } catch (error) {
      console.error('Error fetching Proxmox config:', error);
    }
  };
  
  const fetchLXCs = async () => {
    try {
      const response = await fetch('/api/lxc/config');
      const data = await response.json();
      setLxcs(data?.lxcs ?? []);
    } catch (error) {
      console.error('Error fetching LXCs:', error);
    }
  };
  
  const handleTestProxmox = async () => {
    setTestingProxmox(true);
    setProxmoxSuccess(null);
    
    try {
      const response = await fetch('/api/proxmox/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: proxmoxUrl,
          username: proxmoxUsername,
          token: proxmoxToken,
        }),
      });
      
      const data = await response.json();
      setProxmoxSuccess(data?.success ?? false);
    } catch (error) {
      console.error('Error testing Proxmox:', error);
      setProxmoxSuccess(false);
    } finally {
      setTestingProxmox(false);
    }
  };
  
  const handleSaveProxmox = async () => {
    try {
      await fetch('/api/proxmox/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: proxmoxUrl,
          username: proxmoxUsername,
          token: proxmoxToken,
        }),
      });
      
      alert('Configuration Proxmox sauvegardée');
    } catch (error) {
      console.error('Error saving Proxmox config:', error);
      alert('Erreur lors de la sauvegarde');
    }
  };
  
  const handleScanLXCs = async () => {
    setShowScanModal(true);
    setScanning(true);
    setScanError(null);
    setScannedLxcs([]);
    setSelectedLxcs(new Set());
    
    try {
      const response = await fetch('/api/proxmox/scan');
      const data = await response.json();
      
      if (!response.ok) {
        setScanError(data?.error ?? 'Erreur lors du scan');
      } else {
        setScannedLxcs(data?.lxcs ?? []);
      }
    } catch (error) {
      console.error('Error scanning LXCs:', error);
      setScanError('Erreur lors du scan des LXC');
    } finally {
      setScanning(false);
    }
  };
  
  const toggleLxcSelection = (vmid: number) => {
    const newSelected = new Set(selectedLxcs);
    if (newSelected.has(vmid)) {
      newSelected.delete(vmid);
    } else {
      newSelected.add(vmid);
    }
    setSelectedLxcs(newSelected);
  };
  
  const handleProceedToConfig = () => {
    const selected = scannedLxcs.filter(lxc => selectedLxcs.has(lxc.vmid) && !lxc.alreadyAdded);
    if (selected.length === 0) return;
    
    setScannedToConfig(selected);
    
    // Initialiser les configs par défaut
    const configs: {[key: number]: {sshUsername: string; sshPassword: string; sshPort: string}} = {};
    selected.forEach(lxc => {
      configs[lxc.vmid] = {
        sshUsername: 'root',
        sshPassword: '',
        sshPort: '22',
      };
    });
    setScannedConfigs(configs);
    
    setConfiguringScanned(true);
  };
  
  const handleAddSelectedLxcs = async () => {
    setAddingFromScan(true);
    
    try {
      for (const lxc of scannedToConfig) {
        const config = scannedConfigs[lxc.vmid];
        
        await fetch('/api/lxc/config', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            proxmoxId: lxc.vmid.toString(),
            name: lxc.name,
            ipAddress: lxc.ipAddress,
            sshPort: config.sshPort,
            sshUsername: config.sshUsername,
            sshPassword: config.sshPassword,
            sshKey: '',
          }),
        });
      }
      
      setShowScanModal(false);
      setConfiguringScanned(false);
      setScannedToConfig([]);
      setSelectedLxcs(new Set());
      fetchLXCs();
      
    } catch (error) {
      console.error('Error adding LXCs:', error);
      alert('Erreur lors de l\'ajout des LXC');
    } finally {
      setAddingFromScan(false);
    }
  };
  
  const handleTestSSH = async () => {
    try {
      const response = await fetch('/api/lxc/test-ssh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ipAddress: formData.ipAddress,
          sshPort: parseInt(formData.sshPort),
          sshUsername: formData.sshUsername,
          sshPassword: formData.sshPassword || undefined,
          sshKey: formData.sshKey || undefined,
        }),
      });
      
      const data = await response.json();
      
      if (data?.success) {
        alert('Connexion SSH réussie !');
      } else {
        alert('Connexion SSH échouée');
      }
    } catch (error) {
      console.error('Error testing SSH:', error);
      alert('Erreur lors du test SSH');
    }
  };
  
  const handleSaveLXC = async () => {
    try {
      const url = editingId
        ? `/api/lxc/config/${editingId}`
        : '/api/lxc/config';
      
      const method = editingId ? 'PUT' : 'POST';
      
      await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      setShowAddForm(false);
      setEditingId(null);
      setFormData({
        proxmoxId: '',
        name: '',
        ipAddress: '',
        sshPort: '22',
        sshUsername: '',
        sshPassword: '',
        sshKey: '',
      });
      
      fetchLXCs();
    } catch (error) {
      console.error('Error saving LXC:', error);
      alert('Erreur lors de la sauvegarde');
    }
  };
  
  const handleDeleteLXC = async (id: string) => {
    if (!confirm('Voulez-vous vraiment supprimer ce LXC ?')) return;
    
    try {
      await fetch(`/api/lxc/config/${id}`, { method: 'DELETE' });
      fetchLXCs();
    } catch (error) {
      console.error('Error deleting LXC:', error);
      alert('Erreur lors de la suppression');
    }
  };
  
  const handleEditLXC = (lxc: LXCConfig) => {
    setEditingId(lxc?.id ?? null);
    setFormData({
      proxmoxId: lxc?.proxmoxId?.toString() ?? '',
      name: lxc?.name ?? '',
      ipAddress: lxc?.ipAddress ?? '',
      sshPort: lxc?.sshPort?.toString() ?? '22',
      sshUsername: lxc?.sshUsername ?? '',
      sshPassword: lxc?.sshPassword ?? '',
      sshKey: lxc?.sshKey ?? '',
    });
    setShowAddForm(true);
  };
  
  const formatBytes = (bytes: number) => {
    if (!bytes) return 'N/A';
    const gb = bytes / (1024 * 1024 * 1024);
    return `${gb.toFixed(1)} GB`;
  };
  
  return (
    <div className="container mx-auto max-w-5xl px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold mb-2">Configuration</h1>
        <p className="text-muted-foreground">
          Configurez votre connexion Proxmox et ajoutez vos LXC à surveiller
        </p>
      </motion.div>
      
      {/* Proxmox Configuration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="rounded-lg bg-card p-6 shadow-md mb-8"
      >
        <div className="flex items-center gap-2 mb-6">
          <Settings className="h-5 w-5 text-primary" />
          <h2 className="text-xl font-semibold">Connexion Proxmox</h2>
        </div>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">URL du serveur Proxmox</label>
            <input
              type="text"
              value={proxmoxUrl}
              onChange={(e) => setProxmoxUrl(e.target.value)}
              placeholder="https://proxmox.example.com:8006"
              className="w-full px-4 py-2 rounded-lg border bg-background"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Nom d&apos;utilisateur API</label>
            <input
              type="text"
              value={proxmoxUsername}
              onChange={(e) => setProxmoxUsername(e.target.value)}
              placeholder="user@pam!token"
              className="w-full px-4 py-2 rounded-lg border bg-background"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Token API</label>
            <input
              type="password"
              value={proxmoxToken}
              onChange={(e) => setProxmoxToken(e.target.value)}
              placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
              className="w-full px-4 py-2 rounded-lg border bg-background"
            />
          </div>
          
          <div className="flex gap-3 flex-wrap">
            <button
              onClick={handleTestProxmox}
              disabled={testingProxmox}
              className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors disabled:opacity-50"
            >
              {testingProxmox ? 'Test en cours...' : 'Tester la connexion'}
            </button>
            
            <button
              onClick={handleSaveProxmox}
              className="px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Sauvegarder
            </button>
            
            {proxmoxSuccess !== null && (
              <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                proxmoxSuccess
                  ? 'bg-green-500/20 text-green-700 dark:text-green-300'
                  : 'bg-red-500/20 text-red-700 dark:text-red-300'
              }`}>
                {proxmoxSuccess ? (
                  <><Check className="h-4 w-4" /> Connexion réussie</>
                ) : (
                  <><X className="h-4 w-4" /> Connexion échouée</>
                )}
              </div>
            )}
          </div>
        </div>
      </motion.div>
      
      {/* LXC Configuration */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="rounded-lg bg-card p-6 shadow-md"
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Server className="h-5 w-5 text-primary" />
            <h2 className="text-xl font-semibold">LXC à surveiller</h2>
          </div>
          
          {!showAddForm && (
            <div className="flex gap-2">
              <button
                onClick={handleScanLXCs}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
              >
                <Search className="h-4 w-4" />
                Scanner les LXC
              </button>
              
              <button
                onClick={() => {
                  setShowAddForm(true);
                  setEditingId(null);
                  setFormData({
                    proxmoxId: '',
                    name: '',
                    ipAddress: '',
                    sshPort: '22',
                    sshUsername: '',
                    sshPassword: '',
                    sshKey: '',
                  });
                }}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
              >
                <Plus className="h-4 w-4" />
                Ajout manuel
              </button>
            </div>
          )}
        </div>
        
        {showAddForm && (
          <div className="mb-6 p-4 rounded-lg bg-muted/50 border">
            <h3 className="text-lg font-medium mb-4">
              {editingId ? 'Éditer le LXC' : 'Ajouter manuellement un LXC'}
            </h3>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">ID Proxmox</label>
                <input
                  type="number"
                  value={formData.proxmoxId}
                  onChange={(e) => setFormData({ ...formData, proxmoxId: e.target.value })}
                  placeholder="100"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Nom personnalisé</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Mon LXC"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Adresse IP</label>
                <input
                  type="text"
                  value={formData.ipAddress}
                  onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                  placeholder="192.168.1.100"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Port SSH</label>
                <input
                  type="number"
                  value={formData.sshPort}
                  onChange={(e) => setFormData({ ...formData, sshPort: e.target.value })}
                  placeholder="22"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Utilisateur SSH</label>
                <input
                  type="text"
                  value={formData.sshUsername}
                  onChange={(e) => setFormData({ ...formData, sshUsername: e.target.value })}
                  placeholder="root"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Mot de passe SSH</label>
                <input
                  type="password"
                  value={formData.sshPassword}
                  onChange={(e) => setFormData({ ...formData, sshPassword: e.target.value })}
                  placeholder="(optionnel si clé SSH)"
                  className="w-full px-4 py-2 rounded-lg border bg-background"
                />
              </div>
            </div>
            
            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">Clé privée SSH (optionnel)</label>
              <textarea
                value={formData.sshKey}
                onChange={(e) => setFormData({ ...formData, sshKey: e.target.value })}
                placeholder="-----BEGIN RSA PRIVATE KEY-----"
                rows={3}
                className="w-full px-4 py-2 rounded-lg border bg-background font-mono text-sm"
              />
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={handleTestSSH}
                className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
              >
                Tester SSH
              </button>
              
              <button
                onClick={handleSaveLXC}
                className="px-4 py-2 rounded-lg bg-green-500 text-white hover:bg-green-600 transition-colors"
              >
                {editingId ? 'Mettre à jour' : 'Ajouter'}
              </button>
              
              <button
                onClick={() => {
                  setShowAddForm(false);
                  setEditingId(null);
                }}
                className="px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
              >
                Annuler
              </button>
            </div>
          </div>
        )}
        
        <div className="space-y-3">
          {lxcs?.length === 0 ? (
            <p className="text-sm text-muted-foreground italic text-center py-8">
              Aucun LXC configuré. Utilisez le bouton &quot;Scanner les LXC&quot; pour détecter automatiquement vos LXC ou ajoutez-en un manuellement.
            </p>
          ) : (
            lxcs?.map((lxc) => (
              <div
                key={lxc?.id ?? Math.random()}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                <div>
                  <p className="font-medium">{lxc?.name ?? 'Unknown'}</p>
                  <p className="text-sm text-muted-foreground">
                    LXC {lxc?.proxmoxId ?? 'N/A'} • {lxc?.ipAddress ?? 'N/A'} • {lxc?.sshUsername ?? 'N/A'}@{lxc?.sshPort ?? 22}
                  </p>
                </div>
                
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEditLXC(lxc)}
                    className="p-2 rounded hover:bg-blue-500/20 transition-colors"
                    title="Éditer"
                  >
                    <Edit className="h-4 w-4 text-blue-600" />
                  </button>
                  
                  <button
                    onClick={() => handleDeleteLXC(lxc?.id ?? '')}
                    className="p-2 rounded hover:bg-red-500/20 transition-colors"
                    title="Supprimer"
                  >
                    <Trash2 className="h-4 w-4 text-red-600" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </motion.div>
      
      {/* Modal de scan */}
      <AnimatePresence>
        {showScanModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
            onClick={() => !scanning && !addingFromScan && setShowScanModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-card rounded-xl shadow-xl max-w-3xl w-full max-h-[80vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Monitor className="h-6 w-6 text-primary" />
                    <h2 className="text-xl font-semibold">
                      {configuringScanned ? 'Configurer les LXC sélectionnés' : 'Scanner les LXC Proxmox'}
                    </h2>
                  </div>
                  {!scanning && !addingFromScan && (
                    <button
                      onClick={() => {
                        setShowScanModal(false);
                        setConfiguringScanned(false);
                      }}
                      className="p-2 hover:bg-muted rounded-lg transition-colors"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  )}
                </div>
              </div>
              
              <div className="p-6 overflow-y-auto max-h-[60vh]">
                {scanning ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Loader2 className="h-12 w-12 text-primary animate-spin mb-4" />
                    <p className="text-muted-foreground">Scan des LXC en cours...</p>
                  </div>
                ) : scanError ? (
                  <div className="text-center py-12">
                    <X className="h-12 w-12 text-red-500 mx-auto mb-4" />
                    <p className="text-red-600 dark:text-red-400 mb-4">{scanError}</p>
                    <button
                      onClick={handleScanLXCs}
                      className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600 transition-colors"
                    >
                      Réessayer
                    </button>
                  </div>
                ) : configuringScanned ? (
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground mb-4">
                      Configurez les informations SSH pour chaque LXC sélectionné. Les valeurs par défaut sont pré-remplies.
                    </p>
                    
                    {scannedToConfig.map((lxc) => (
                      <div key={lxc.vmid} className="p-4 rounded-lg border bg-muted/30">
                        <div className="flex items-center gap-3 mb-3">
                          <Monitor className="h-5 w-5 text-primary" />
                          <div>
                            <p className="font-medium">{lxc.name}</p>
                            <p className="text-sm text-muted-foreground">ID: {lxc.vmid} • IP: {lxc.ipAddress || 'Non détectée'}</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-3 gap-3">
                          <div>
                            <label className="block text-xs font-medium mb-1">Utilisateur SSH</label>
                            <input
                              type="text"
                              value={scannedConfigs[lxc.vmid]?.sshUsername || ''}
                              onChange={(e) => setScannedConfigs({
                                ...scannedConfigs,
                                [lxc.vmid]: { ...scannedConfigs[lxc.vmid], sshUsername: e.target.value }
                              })}
                              className="w-full px-3 py-1.5 rounded border bg-background text-sm"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-xs font-medium mb-1">Mot de passe SSH</label>
                            <input
                              type="password"
                              value={scannedConfigs[lxc.vmid]?.sshPassword || ''}
                              onChange={(e) => setScannedConfigs({
                                ...scannedConfigs,
                                [lxc.vmid]: { ...scannedConfigs[lxc.vmid], sshPassword: e.target.value }
                              })}
                              className="w-full px-3 py-1.5 rounded border bg-background text-sm"
                            />
                          </div>
                          
                          <div>
                            <label className="block text-xs font-medium mb-1">Port SSH</label>
                            <input
                              type="number"
                              value={scannedConfigs[lxc.vmid]?.sshPort || '22'}
                              onChange={(e) => setScannedConfigs({
                                ...scannedConfigs,
                                [lxc.vmid]: { ...scannedConfigs[lxc.vmid], sshPort: e.target.value }
                              })}
                              className="w-full px-3 py-1.5 rounded border bg-background text-sm"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : scannedLxcs.length === 0 ? (
                  <div className="text-center py-12">
                    <Server className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-muted-foreground">Aucun LXC détecté</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground mb-4">
                      {scannedLxcs.length} LXC détecté(s). Sélectionnez ceux que vous souhaitez ajouter.
                    </p>
                    
                    {scannedLxcs.map((lxc) => (
                      <div
                        key={lxc.vmid}
                        className={`flex items-center justify-between p-4 rounded-lg border transition-all cursor-pointer ${
                          lxc.alreadyAdded
                            ? 'bg-green-500/10 border-green-500/30 cursor-not-allowed'
                            : selectedLxcs.has(lxc.vmid)
                            ? 'bg-primary/10 border-primary'
                            : 'bg-muted/30 hover:bg-muted/50'
                        }`}
                        onClick={() => !lxc.alreadyAdded && toggleLxcSelection(lxc.vmid)}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                            lxc.alreadyAdded
                              ? 'bg-green-500 border-green-500'
                              : selectedLxcs.has(lxc.vmid)
                              ? 'bg-primary border-primary'
                              : 'border-muted-foreground'
                          }`}>
                            {(lxc.alreadyAdded || selectedLxcs.has(lxc.vmid)) && (
                              <Check className="h-3 w-3 text-white" />
                            )}
                          </div>
                          
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-medium">{lxc.name}</p>
                              <span className={`px-2 py-0.5 text-xs rounded-full ${
                                lxc.status === 'running'
                                  ? 'bg-green-500/20 text-green-700 dark:text-green-300'
                                  : 'bg-gray-500/20 text-gray-700 dark:text-gray-300'
                              }`}>
                                {lxc.status}
                              </span>
                              {lxc.alreadyAdded && (
                                <span className="px-2 py-0.5 text-xs rounded-full bg-green-500/20 text-green-700 dark:text-green-300">
                                  Déjà ajouté
                                </span>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground">
                              ID: {lxc.vmid} • Node: {lxc.node} • IP: {lxc.ipAddress || 'Non détectée'}
                            </p>
                          </div>
                        </div>
                        
                        <div className="text-right text-sm text-muted-foreground">
                          <p>{lxc.cpus} CPU • {formatBytes(lxc.maxmem)}</p>
                          <p>Disque: {formatBytes(lxc.maxdisk)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {!scanning && !scanError && scannedLxcs.length > 0 && (
                <div className="p-6 border-t bg-muted/30">
                  <div className="flex items-center justify-between">
                    {configuringScanned ? (
                      <>
                        <button
                          onClick={() => setConfiguringScanned(false)}
                          className="px-4 py-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
                        >
                          Retour
                        </button>
                        
                        <button
                          onClick={handleAddSelectedLxcs}
                          disabled={addingFromScan}
                          className="flex items-center gap-2 px-6 py-2 rounded-lg bg-green-500 text-white hover:bg-green-600 transition-colors disabled:opacity-50"
                        >
                          {addingFromScan ? (
                            <><Loader2 className="h-4 w-4 animate-spin" /> Ajout en cours...</>
                          ) : (
                            <><CheckCircle2 className="h-4 w-4" /> Ajouter {scannedToConfig.length} LXC</>
                          )}
                        </button>
                      </>
                    ) : (
                      <>
                        <p className="text-sm text-muted-foreground">
                          {selectedLxcs.size} LXC sélectionné(s)
                        </p>
                        
                        <button
                          onClick={handleProceedToConfig}
                          disabled={selectedLxcs.size === 0 || [...selectedLxcs].every(id => scannedLxcs.find(l => l.vmid === id)?.alreadyAdded)}
                          className="flex items-center gap-2 px-6 py-2 rounded-lg bg-primary text-primary-foreground hover:opacity-90 transition-opacity disabled:opacity-50"
                        >
                          <Plus className="h-4 w-4" />
                          Continuer
                        </button>
                      </>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
